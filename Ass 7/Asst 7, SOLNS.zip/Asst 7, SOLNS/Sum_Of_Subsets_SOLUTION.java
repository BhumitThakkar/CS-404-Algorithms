// Sum of Subsets Backtracking

public class Sum_Of_Subsets_SOLUTION  {


// After this method call, if there is a solution, include[0] is 1, and 
// include[1], ..., include[n] is 1 or 0 if item i should be taken or left.
// It will call "SOS_rec"
   
   public static void SOS(int n, int [] w, int Goal, int [] include)  {
   
      int amtLeft = 0;
      for (int j = 1; j <= n; j++)
         amtLeft += w[j];
   
      SOS_rec(0, 0, amtLeft, w, Goal, include);
   }
   

// This method is called by "SOS".  Once a solution has been found, it will not search for 
// any further solutions, and the include array will contain the solution as well as include[0] set to 1.
   
   public static void SOS_rec(int i, int totalSoFar, int amtLeft, int [] w, int Goal, int [] include)  {
   
      if (promising(i, totalSoFar, amtLeft, w, Goal))  {
      
         if (totalSoFar == Goal)
            include[0] = 1;
         
         else  {
         
            include[i+1] = 1;
            SOS_rec(i+1, totalSoFar + w[i+1], amtLeft - w[i+1], w, Goal, include);
            
            if (include[0] == 0)  {
               include[i+1] = 0;
               SOS_rec(i+1, totalSoFar, amtLeft - w[i+1], w, Goal, include);
            }
         }
      }
   }
   
   
// The promising method for SOS_Rec:
   
   public static boolean promising(int i, int totalSoFar, int amtLeft, int [] w, int Goal)  {
   
      return (totalSoFar + amtLeft >= Goal  && 
              (totalSoFar == Goal  ||  totalSoFar + w[i+1] <= Goal));
   }
   
   
//=====================================================================
      
   public static void main(String [] args)  {
      
      int n, Goal, j;
      int [] w;
   
      for (j = 1; j <= NUM_TESTS; j++)  {
      
         n = n_Array[j];
         Goal = Goal_Array[j];
         w = w_Array[j];
      
         int [] include = new int[n+1];
         SOS(n, w, Goal, include);
         
         System.out.println("\nTest " + j + ":  ");
         System.out.print("n = " + n + ", Goal = " + Goal + ", and items are:  ");
         printArray(n, w);
         if (include[0] == 1)  {
            System.out.println("Solution found!  ");
            printSubset(n, include);
         }
         else
            System.out.println("No solution was found.");

      }
   }
   
   public static void printArray(int n, int [] A)  {

      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
      System.out.println();
   }
   
   
   public static void printSubset(int n, int [] A)  {
   
      System.out.print("Take these items:  ");
      for (int i = 1; i <= n; i++)
         if (A[i] == 1)
            System.out.print(i + " ");
      System.out.println();
   }

   public static int [] n_Array = {0, 4, 4, 5, 6, 6, 10, 10, 10};
   public static int [] Goal_Array = {0, 13, 17, 26, 51, 53, 400, 401, 402};
   public static int [][] w_Array = 
      {
         {},
         {0, 3, 4, 5, 6},
         {0, 3, 4, 5, 6},
         {0, 5, 6, 10, 11, 16},
         {0, 2, 10, 13, 17, 22, 42},
         {0, 2, 10, 13, 17, 22, 42},
         {0, 5, 9, 17, 42, 63, 95, 132, 185, 209, 371},
         {0, 5, 9, 17, 42, 63, 95, 132, 185, 209, 371},
         {0, 5, 9, 17, 42, 63, 95, 132, 185, 209, 371}
      };
      
   public static int NUM_TESTS = w_Array.length - 1; 
   


} // end class