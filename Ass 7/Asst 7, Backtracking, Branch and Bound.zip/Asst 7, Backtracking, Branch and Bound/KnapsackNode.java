public class KnapsackNode implements Comparable<KnapsackNode> {

   public int level;
   public double profit;
   public double weight;
   public double bound;
      
   public KnapsackNode(int l, double p, double w) {
   
      level = l;
      profit = p;
      weight = w;
   }
      
   @Override
   public int compareTo(KnapsackNode node)  {
     
      if (this.bound < node.bound)
         return 1;
      else
         return -1;
   }  
}
   
