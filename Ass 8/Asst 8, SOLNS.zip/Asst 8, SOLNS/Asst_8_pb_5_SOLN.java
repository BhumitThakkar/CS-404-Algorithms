import java.util.Scanner; 
import java.util.Random;

public class Asst_8_pb_5_SOLN
{
   public static int [] minMax(int n, int [] A)  {  // Assumes n is even
   
      int i, j, min, max, count = 0;
      int [] soln = new int[3];
      
      count++;
      if (A[1] > A[2])  {
         
         max = A[1];
         min = A[2];
      }
      else {
         max = A[2];
         min = A[1];
      }
      
      for (i = 3; i <= n-1; i = i+2) {
      
         count++;
         if (A[i] > A[i+1])  {

            count++;
            if (A[i] > max)
               max = A[i];
               
            count++;
            if (A[i+1] < min)
               min = A[i+1];
         }
         else  {
         
            count++;
            if (A[i] < min)
               min = A[i];
            
            count++;
            if (A[i+1] > max)
               max = A[i+1];
         }
      
      }
   
      soln[0] = count;
      soln[1] = min;
      soln[2] = max;
      
      return soln;
   }
   
//========================================================================

	public static void main(String[] args)  {
   
      Random rand = new Random();
      Scanner kbd = new Scanner(System.in);
      int testAgain = 1;
      int i, n, count, min, max, A[], soln[];

      System.out.println();

      System.out.print("Enter even n (or odd n to quit):  ");
      n = kbd.nextInt();
      
      while (n % 2 == 0) {
      


         A = new int[n+1];
  
         for (i = 1; i <= n; i++) 
            A[i] = rand.nextInt(100) + 1;
         
         soln = minMax(n, A);
         
         count = soln[0];
         min = soln[1];
         max = soln[2];
         
         System.out.print("\nArray A is [ ");
         printArray(n, A);
         System.out.println("].\n");
         
         System.out.println("Exactly " + count + " comparison(s) were made.");
         System.out.println("Minimum = " + min);
         System.out.println("Maximum = " + max);
         
         System.out.print("\nEnter even n (or odd n to quit):  ");
         n = kbd.nextInt();            

      }
      
      System.out.println("Bye!");
   }
   
//========================================================================

   public static void printArray(int n, int [] A) {
      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
   }



} // end class