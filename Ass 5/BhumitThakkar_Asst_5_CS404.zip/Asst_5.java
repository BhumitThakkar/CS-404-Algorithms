// CS-404, Fall 2019, Assignment 5 Solutions
// Bhumit Thakkar

package assignment5;

public class Asst_5 { 


   public static void main(String [] args)  {

      System.out.println("Bhumit Thakkar");
      System.out.println("CS-404, Fall 2019, Assignment 5");
      
      A5_Helper.runProblem2();
      A5_Helper.runProblem3();
      A5_Helper.runProblem4();
      A5_Helper.runProblem5();
      A5_Helper.runProblem6();
      A5_Helper.runProblem7();

   }

//////////////////////////////////////////////////////////////////////
// Problem 2

   public static void printTree(int n, int [] nearest) {
	   int flag = 1;
	   System.out.print("{");
	   for (int i = 1; i <= n ; i++) {
		   if(i == nearest[i]) {
			   continue;
		   }
		   else{
			   if (flag == 1) {
				flag = 0;
			   }
			   else {
				   System.out.print(", ");   
			   }
			   System.out.print("{"+i+","+nearest[i]+"}");
		   }
	   }
	   System.out.println("}");
   }

   public static int prim(int n, int [][] W, int s, int [] nearest) {
	   int mst = 0;
	   
	   int distance[] = new int[nearest.length];
	   for (int i = 1; i < distance.length; i++) {
		   distance[i] = inf;
		   nearest[i] = s;
	   }
	   
	   int vnear = s;
	   
	   for (int completing = 1; completing <= n; completing++) {
		   for (int i = 1; i < nearest.length; i++) {
		   		if (distance[i] == 0) {
					continue;
				}
		   		else {
		   			if(W[i][vnear] < distance[i]) {
						distance[i] = W[i][vnear];
						nearest[i] = vnear;
					}
			   	}
		   }

/*		   System.out.println();
		   for (int j = 1; j <= n; j++) {
			   System.out.println(j+" "+ nearest[j] +" "+ distance[j]);
		   }
*/


		   // selecting next vnear or returning -1
	   	   if(completing != n) {
		   	   int minDist = inf;
			   for (int j = 1; j < distance.length; j++) {
				   if( (distance[j] != 0) && (distance[j] < minDist) ) {
					   minDist = distance[j];
			   		   vnear = j;
			   	   }
			   }

			   if (minDist == inf) {
				   return -1;										// No nearest edge found
			   }
			   else {
			   	   // adding the distance in mst
				   mst = mst + distance[vnear];
				   
				   // making distance of selected vertex 0 AFTER ADDING IT'S DISTANCE TO MST
			   	   distance[vnear] = 0;
			   }
	   	   }
	   }
	   
      return mst;
   }
   

//////////////////////////////////////////////////////////////////////
// Problem 3

   public static void dijkstra(int n, int [][] W, int s, int [] touch, int [] pathCost) {
	   
	   int pathLength[] = new int[touch.length];
	   for (int i = 1; i < pathLength.length; i++) {
		   pathLength[i] = inf;
		   pathCost[i] = 0;
		   touch[i] = s;
	   }
	   
	   int vnear = s;
	   
	   for (int completing = 1; completing <= n; completing++) {
		   for (int i = 1; i < touch.length; i++) {
		   		if (pathLength[i] == 0) {
					continue;
				}
		   		else {
		   			int weight = W[vnear][i] + pathCost[vnear]; 
		   			if(weight  < pathLength[i]) {
						pathLength[i] = weight;
						touch[i] = vnear;
					}
			   	}
		   }

//		   System.out.println();
//		   for (int j = 1; j <= n; j++) {
//			   System.out.println(j+" "+ touch[j] +" "+ pathLength[j] +" "+pathCost[j]);
//		   }


		   // selecting next vnear
	   	   if(completing != n) {
		   	   int minDist = inf;
			   for (int j = 1; j < pathLength.length; j++) {
				   if( (pathLength[j] != 0) && (pathLength[j] < minDist) ) {
					   minDist = pathLength[j];
			   		   vnear = j;
			   	   }
			   }
			   
			   if (minDist != inf) {
				   // Adding the pathLength to pathCost
				   pathCost[vnear] = pathLength[vnear];

				   // making pathLength of selected vertex 0 AFTER ADDING IT'S DISTANCE pathCost
			   	   pathLength[vnear] = 0;
			   }
			   else {
				   System.out.println("Two Disjoint Trees");
			   }
   	   	   }
	   }
   }


//////////////////////////////////////////////////////////////////////
// Problem 4

   public static void dijkstraPrintPath(int s, int d, int [] touch)  {
	   int next = d;
	   int ans[] = new int[touch.length];
	   int count = 1;
	   do{
		   ans[count++] = next;
		   next = touch[next];
	   }while(next != s);
	   if(d != s) {
		   ans[count] = s;
	   }
	   else {
		   count--;
	   }
	   for (int i = count; i >= 1; i--) {
		   System.out.print("v"+ans[i]+" ");
	   }
   }


//////////////////////////////////////////////////////////////////////
// Problem 5

   public static int [] smarterGreedyAlgorithm1 (int n, int k, int [] D) {        

      int [] best = new int[k+1];
      for (int i = 0; i < best.length; i++) {
    	  best[i] = inf;
      }
      
      int [] quantity = new int[k+1];
      int target;
      int sum = 0;
      
      for (int i = k; i >= 1; i--) {
    	  for (int j = 1; j < quantity.length; j++) {
    		  quantity[j] = 0;
    	  }
    	  target = n;
    	  sum = 0;
		  int next = i;
		  
    	  while (target != 0) {
    		  while (target >= D[next]) {
    			  target = target - D[next];
    			  quantity[next]++;
    		  }
    		  next--;
    	  }
    	  for (int j = 1; j < quantity.length; j++) {
    		  sum = sum + quantity[j];
    	  }
    	  if(sum < best[0]) {
    		  best[0] = sum;
    		  for (int j = 1; j < quantity.length; j++) {
        		  best[j] = quantity[j];
        	  }
    	  }
//          for (int j = 0; j < quantity.length; j++) {
//    		  System.out.print(best[j]+" ");
//    	  }
//          System.out.println();
      }
      return best;
   }
   
   
//////////////////////////////////////////////////////////////////////
// Problem 6
// 
// Assumes arrays already sorted in descending order by price per pound.
//

   public static double [] greedyFractionalKnapsack(int n, double capacity, double [] profit, double [] weight) {
   
      double quantity [] = new double[n+1];
      
      //ratio = profit/weight
      double ratio[][] = new double[n+1][3];
      for (int i = 1; i <= n; i++) {
    	  ratio[i][1] = profit[i] / weight[i];
    	  ratio[i][2] = i;
      }
      
      //sorting ratio acc to col 1
      for (int i = 1; i < ratio.length; i++) {
    	  for (int j = 1; j < ratio.length - i; j++) {
    		  if(ratio[j][1] < ratio[j+1][1]) {
    			  double temp[] = ratio[j]; 
    			  ratio[j] = ratio[j+1];
    			  ratio[j+1] = temp;
    		  }
    	  }
      }
      
//      for (int i = 1; i < ratio.length; i++) {
//    	  System.out.println(ratio[i][1] + " "+ ratio[i][2]);
//      }
      
	  int next=1;
      while(capacity != 0 && next <= n) {
    	  int currentItem = (int)ratio[next][2];
    	  double nextItemWeight = weight[ currentItem ];
    	  if(capacity >= nextItemWeight ) {
    		  quantity[currentItem] = 1;
    		  quantity[0] = quantity[0] + profit[currentItem];
    		  capacity = capacity - nextItemWeight;
    	  }
    	  else {
    		  quantity[(int)ratio[next][2]] = capacity / nextItemWeight;
    		  quantity[0] = quantity[0] + profit[currentItem]*quantity[currentItem];
    		  capacity = capacity - weight[currentItem]*quantity[currentItem];
    	  }
    	  next++;
      }
      
//      for (int i = 1; i < quantity.length; i++) {
//    	  if (quantity[i] == 1) {
//    		  System.out.println("Item "+i+": all of it");
//    	  }
//    	  else if(quantity[i]!=0) {
//    		  System.out.println("Item "+i+": "+quantity[i]+" of it");
//    	  }
//      }
      return quantity;
   }
         

//////////////////////////////////////////////////////////////////////
// Problem 7
         
   public static int greedyColoring(int n, int [][] W, int [] vcolor)  {
	   int color = 0;
	   boolean emptyVertexFound = true;
	   boolean cantColor = false;
	   while(emptyVertexFound) {								// till all vertex colored
		   color++;												// picking new color
		   for (int i = 1; i < vcolor.length; i++) {			// start coloring
			   if(vcolor[i]==0) {								// only color those which are not colored
				   cantColor = false;
				   for (int j = i-1; j >= 1; j--) {				// go back and search all with similar current color
					   if(vcolor[j] == color) {					// for similar color vertex
						   if(W[j][i] == 1) {					// if there is a link
							   cantColor = true;				// don't color then
						   }
					   }
				   }
				   
				   if (!cantColor) {							// if no link found
					   vcolor[i] = color;						// color the vertex then
				   }
				   
			   }
		   }
		   // termination condition
		   emptyVertexFound = false;
		   for (int i = 1; i < vcolor.length; i++) {
			   if(vcolor[i] == 0) {
				   emptyVertexFound = true;
			   }
		   }
	   }
	   
      return color;
    }

// ===== done ===========================================================================   
   
   
   public static int inf = Integer.MAX_VALUE - 100000;
   
} // end class

      
   


      

