package assignment7;

public class KnapsackNode implements Comparable<KnapsackNode> {

   public int level;
   public double profit;
   public double weight;
   public double bound;
   public int path[];
   
      
   public KnapsackNode(int l, double p, double w, int[] path) {
      level = l;
      profit = p;
      weight = w;
      this.path = path;
   }      
   @Override
   public int compareTo(KnapsackNode node)  {
     
      if (this.bound < node.bound)
         return 1;
      else
         return -1;
   }  
}
   
