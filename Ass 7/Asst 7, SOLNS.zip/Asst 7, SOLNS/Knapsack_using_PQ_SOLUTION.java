// CS-404, Knapsack Using Priority Queue.

import java.util.Objects;
import java.util.PriorityQueue;


public class Knapsack_using_PQ_SOLUTION  {

// Use this global variable to keep track of how many nodes are visited:
   public static int numNodesVisited = 0;
   
   
// NO RECURSION is allowed for the following method (o.w. 0 points).
// The following method uses the best first searh using a Priority Queue.
// The method returns the optimal profit for the instance of the 
// 0-1 knapsack problem given n, p, w, and W. 
// After the method call, best[i] is set to 1 if item i should be taken, and is set to 0 otherwise.
// Also, after this method is called, the global variable "numNodesVisited" will contain
// the number of nodes visited to solve this instance. 

// Use the Priority Queue methods "isEmpty()", "add(v)" (which enqueues KnapsackNode v"),
// and "remove()" (which dequeues and returns the KnapsackNode with the largest bound).
   
   public static double knapsack_PQ(int n, double [] p, double [] w, double W, int [] best)  {
   
      PriorityQueue<KnapsackNode> PQ = new PriorityQueue<>();
      
      double greedyBound, maxProfit = 0;

      KnapsackNode u, v;
      
      v = new KnapsackNode(0, 0, 0); 
      v.bound = bound(v, n, p, w, W);
      numNodesVisited++;
           
      PQ.add(v);
      
      while(!PQ.isEmpty()) {
         
         v = PQ.remove();
         
         if (v.profit > maxProfit)  
            maxProfit = v.profit;
         
         if (v.bound > maxProfit) {
    
            int i = v.level;

            u = new KnapsackNode(i+1, v.profit + p[i+1], v.weight + w[i+1]);
            numNodesVisited++;
            u.bound = bound(u, n, p, w, W);
            if (u.bound > maxProfit)
               PQ.add(u);

            u = new KnapsackNode(i+1, v.profit, v.weight);
            numNodesVisited++;
            u.bound = bound(u, n, p, w, W);
            if (u.bound > maxProfit)
               PQ.add(u);
         }
      }
      return maxProfit;
   }


// The following method takes a KnapsackNode u (which contains its level, profit, and weight)
// and computes and returns its bound (see method "bound" on page 256).
 
   public static double bound(KnapsackNode u, int n, double [] p, double [] w, double W)  {
      
      if (u.weight > W)
         return 0;
      
      double boundSoFar = u.profit;
      double totalWeight = u.weight;
      int j = u.level + 1;
      
      while (j <= n  &&  totalWeight + w[j] <= W)  {
         
         totalWeight += w[j];
         boundSoFar += p[j];
         j++;
      }
      
      if (j <= n)
         boundSoFar +=  (W - totalWeight) * p[j]/w[j];
      
      return boundSoFar;
   }
   
   

//=======================================================================
  
   public static void main(String [] args)  {
      
      int n;
      double w [], p [], W, maxProfit;
   
      for (int j = 1; j <= NUM_TESTS; j++)  {
      
         p = p_Array[j];
         w = w_Array[j];
         n = p.length - 1;
         W = capacity_Array[j];
      
         int [] best = new int[n+1];
         numNodesVisited = 0;
         maxProfit = knapsack_PQ(n, p, w, W, best);
         
         System.out.println("\nTest " + j + ":  ");
         System.out.println("0-1 optimal profit:  $" + maxProfit);
         System.out.println("Number of nodes visited:  " + numNodesVisited);
      }
   }
   
   
   public static double [] capacity_Array = {0, 11, 16, 13, 25, 405, 13};   
   
   public static double [][] p_Array = 
      {
         {},
         {0, 20, 30, 35, 12, 3},
         {0, 40, 30, 50, 10},
         {0, 20, 30, 35, 12, 3},         
         {0, 18, 30, 40, 21, 24},
         {0, 320, 350, 900, 700, 650, 420, 504, 600, 150, 120},
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 13},
      };
      
   public static double [][] w_Array = 
      {
         {},
         {0, 2, 5, 7, 3, 1},
         {0, 2, 5, 10, 5},
         {0, 2, 5, 7, 3, 1},
         {0, 3, 6, 10, 7, 12},
         {0, 85, 95, 250, 200, 195, 140, 170, 230, 60, 50},
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 13},        
      };
  
   public static int NUM_TESTS = p_Array.length - 1; 
   
}