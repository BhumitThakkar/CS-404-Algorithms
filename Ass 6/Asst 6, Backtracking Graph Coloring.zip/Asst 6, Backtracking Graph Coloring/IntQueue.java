public class IntQueue 
{

  public IntQueue()
  {


  }
  

  public void enqueue(int element)
  // Adds element to the rear of this queue.
  { 



  }     

  public int dequeue()
  // Removes front element from this queue and returns it.
  {


      return -1;
  }

  public boolean isEmpty()
  // Returns true if this queue is empty; otherwise, returns false.
  {              


      return true;
  }
}

