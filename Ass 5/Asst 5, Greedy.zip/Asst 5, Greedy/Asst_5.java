// CS-404, Fall 2019, Assignment 5 Solutions
// YOUR_NAME_HERE


public class Asst_5 { 


   public static void main(String [] args)  {

      System.out.println("YOUR NAME HERE");
      System.out.println("CS-404, Fall 2019, Assignment 5");
      
      A5_Helper.runProblem2();
      A5_Helper.runProblem3();
      A5_Helper.runProblem4();
      A5_Helper.runProblem5();
      A5_Helper.runProblem6();
      A5_Helper.runProblem7();

   }

//////////////////////////////////////////////////////////////////////
// Problem 2

   public static void printTree(int n, int [] nearest) {
   

   }

   public static int prim(int n, int [][] W, int s, int [] nearest) {
   
   
      return -1;
   }
   

//////////////////////////////////////////////////////////////////////
// Problem 3

   public static void dijkstra(int n, int [][] W, int s, int [] touch, int [] pathCost) {


   }


//////////////////////////////////////////////////////////////////////
// Problem 4

   public static void dijkstraPrintPath(int s, int d, int [] touch)  {
   

   }


//////////////////////////////////////////////////////////////////////
// Problem 5

   public static int [] smarterGreedyAlgorithm1 (int n, int k, int [] D) {        

      int [] quantity = new int[n+1];


      return quantity;
   }
   
   
//////////////////////////////////////////////////////////////////////
// Problem 6
// 
// Assumes arrays already sorted in descending order by price per pound.
//

   public static double [] greedyFractionalKnapsack(int n, double capacity, double [] profit, double [] weight) {
   
      double quantity [] = new double[n+1];
      

      return quantity;
   }
         

//////////////////////////////////////////////////////////////////////
// Problem 7
         
   public static int greedyColoring(int n, int [][] W, int [] vcolor)  {



      return -1;
    }

// ===== done ===========================================================================   
   
   
   public static int inf = Integer.MAX_VALUE - 100000;
   
} // end class
   
      
   


      

