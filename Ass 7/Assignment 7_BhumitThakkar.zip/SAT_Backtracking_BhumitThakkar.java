// CS-404, Satisfiability Backtracking
// Bhumit Thakkar

import java.util.Scanner;
import java.io.*;  


public class SAT_Backtracking_BhumitThakkar
{

// If formula F is NOT satisfiable, then "satisfy" returns false.
// If formula F IS satisfiable, then truthAsst contains a satisfying assignment (with truthAsst[i] = 1 
// if and only if variable x_{i} is assigned to true) and the method returns true. You may use any 
// value other than 1 to denote "false".  This method calls satisfyRec.

   public static boolean satisfy(int n, int k, int [][] F, int [] truthAsst)  {
	   satisfyRec(0, n, k, F, truthAsst);
	   if(truthAsst[0] == 1) {
		   return true;
	   }
	   else
		   return false;
   }
   

// This method does the backtracking to search for a satisfying truth assignment.  
// Once (if) it finds a satisfying truth assignment, it does not search for another one (0 points if you do).
   
   public static void satisfyRec(int i, int n, int k, int [][] F, int [] truthAsst)
   {
	   boolean promising = promising(i, k, F, truthAsst);
	   if(promising) {
		   if(i == n) {
			   truthAsst[0] = 1;
			   return;
		   }
		   else if(i < n){
			   truthAsst[i+1] = 1;								// true
			   satisfyRec(i+1, n, k, F, truthAsst);
			   if(truthAsst[0] != 1) {
				   truthAsst[i+1] = -1;							// false
				   satisfyRec(i+1, n, k, F, truthAsst);
			   }
		   }
	   }
   }
            

// The promising method for satisfyRec:

   public static boolean promising(int i, int k, int [][] F, int [] truthAsst)
   {		   
	   
	   for (int r = 1; r <= k; r++) {
		   boolean rRow = false;
		   for (int c = 1; c <= 3; c++) {
			   int rMult = 1;
			   if(F[r][c] < 0) {
				   if( (-1 * F[r][c]) <= i )		// To ignore the truth values assigned for bigger level but didn't resulted
					   rMult = -1 * truthAsst[-1 * F[r][c]];
				   else
					   rMult = 0;
			   }
			   else {
				   if( (1 * F[r][c]) <= i )			// To ignore the truth values assigned for bigger level but didn't resulted
					   rMult = 1 * truthAsst[1 * F[r][c]];
				   else
					   rMult = 0;
			   }
			   if(rMult > -1) {
				   rRow = true;
				   break;
			   }
		   }
		   if(rRow == false) {
			   return false;
		   }
	   }

      return true;  // this is just so it compiles now
   }


//========================================================================

	public static void main(String[] args) throws IOException  {

		Scanner kbd = new Scanner(System.in);
		Scanner input;	      
		String inputFilePath = Clique_Backtracking_BhumitThakkar.class.getResource("formulas.txt").toString();
		// If not in main use: this.getClass().getResource("words.txt");
		inputFilePath = inputFilePath.replace("%20", " ");
		inputFilePath = inputFilePath.replace("file:/", "");
//		System.out.println(inputFilePath);
		FileReader f = new FileReader(inputFilePath);
		input = new Scanner(f);  
	      
//      FileReader f = new FileReader("formulas.txt");
//      Scanner input = new Scanner(f);
      int n, k, i = 0;
      int [][] F;
      int [] truthAsst;
      
      while (input.hasNext())
      {
         i++;
         n = input.nextInt();
         k = input.nextInt();
         F = getNextFormula(k, input);
         truthAsst = new int[n+1];

         satisfy(n, k, F, truthAsst);
                  
         System.out.println("\nFormula " + i + ", n = " + n + ", k = " + k);

         if (truthAsst[0] == 0)
            System.out.println("This formula is NOT satisfiable!");
         else  {
            System.out.println("This forumla IS SATISFIED by this assignment:");      
            printAsst(n, truthAsst);
         }

      }
   }
   

   
   public static void printAsst(int n, int [] truthAsst)
   {
      for (int i = 1; i <= n - 1; i++)
      {
         System.out.print("x_{" + i + "} = ");
         if (truthAsst[i] == 1) 
            System.out.print("T, ");
         else
            System.out.print("F, ");
      }
      
      System.out.print("x_{" + n + "} = ");
      if (truthAsst[n] == 1) 
         System.out.print("T.");
      else
         System.out.print("F.");

         
      System.out.println();
   }

   
   public static int [][] getNextFormula(int k, Scanner input)
   {
      int [][] F = new int[k+1][4];

      for (int i = 1; i <= k; i++) 
         for (int j = 1; j <= 3; j++)
            F[i][j] = input.nextInt();
      
      return F;
   }
   
      


} // end class