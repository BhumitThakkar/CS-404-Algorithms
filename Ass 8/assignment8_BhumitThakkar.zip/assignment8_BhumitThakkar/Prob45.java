// Bhumit Thakkar
// CS 404

package assignment8;

public class Prob45 {
	
	public static void main(String[] args) {
		// 1 to n	ignore 0th index by keeping its value as 0
		int As[][] = {
				{0,4,2,5,6},
				{0,2,1},
				{0,16,99,30,1,8},
				{0,999,25,1000,3},
				{0, 36, 58, 47, 95, 21, 48},
				{0, 600, 500, 400, 300, 200, 100, 50, 1}		// <<Add your array here, start with 0 and then even numbers
				};
		
		for(int[] A : As) {
			int minMax[] = minMax(A.length-1, A);
			if(minMax[0] != 0 && minMax[1] != 0)
				System.out.println("\t\t\t\tMinimum for A: "+minMax[0]+" & Maximum for A: "+minMax[1]);
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println();
		}
		
	}

	// ===================================IMPORTANT NOTE===================================
	//	int A[] = {0, 1, 25, 36, 21, 33}; 					----> Example for Prob 4
	//	int n = A.length - 1;								----> n for Prob 4
	//	int g = 26;
	//	reduce_SOS_to_PARTITION(n, A, g);
	// ===================================IMPORTANT NOTE===================================
	public static int [] reduce_SOS_to_PARTITION(int n, int [] A, int g) {
	// Array A runs from 1 to n    - length of array: n+1
	// Array B runs from 1 to n+2  - length of array: n+3
		int B[] = new int[n+3];
		int T = 0;
		for (int i = 1; i < A.length; i++) {
			T =T + A[i];
			B[i] = A[i];
		}
		int L2 = 1000*T;
		int L1 = 1001*T - 2*g;
		B[n+1] = L1;
		B[n+2] = L2;
		return B;
	}
	
	public static int [] minMax(int n, int [] A) {
		// Assuming no duplicates in A
		int round = (3*n/2) - 2;
		int minMax[] = new int[2];
		boolean WL[][] = new boolean[A.length][2];						// [0] = win, [1] = lose
		if(n>=2 && n%2 == 0) {
			for(int r=1; r <= round; r++) {
				if(r==1) {
					for(int r2=1; r2<=n; r2=r2+2 ) {
						r++;
						if(A[r2] < A[r2+1]) {
							WL[r2+1][0] = true;
							WL[r2][1] = true;
						}
						else {
							WL[r2][0] = true;							
							WL[r2+1][1] = true;
						}
					}
					r--;						// because r starts from 1 get 2 rounds = total equals 3 so to reduce 1; 
				}
				else {
					int goOut = 0;
					for(int i = 1; i< WL.length; i++) {
						if(WL[i][0] == WL[i][1] || A[i] == minMax[0] || A[i] == minMax[1]) {
							continue;
						}
						else {											// found with W or L but not both
							if(WL[i][0] == true) {						// if found is W
								int flag = 0;
								for(int j = i+1; j< WL.length; j++) {
									if(WL[j][0] != WL[j][1] && WL[j][0] == true) {
										if(A[i] < A[j]) {
											WL[i][1] = true;
										}
										else {
											WL[j][1] = true;
										}
										flag = 1;
										goOut = 1;
										break;
									}
								}
								if(flag == 0) {
									minMax[1] = A[i];					// no other W found true whole L is false					
								}
								if(goOut == 1) {
									break;
								}
							}
							else {										// if found is L
								int flag = 0;
								for(int j = i+1; j< WL.length; j++) {
									if(WL[j][0] != WL[j][1] && WL[j][1] == true) {
										if(A[i] < A[j]) {
											WL[j][0] = true;
										}
										else {
											WL[i][0] = true;
										}
										flag = 1;
										goOut = 1;
										break;
									}
								}
								if(flag == 0) {
									minMax[0] = A[i];					// no other L found true whole W is false
								}
								if(goOut == 1) {
									break;
								}
							}
						}
					}
				}
			}
			
			if(minMax[0] == 0 || minMax[1] == 0)							// If either of them are yet not found
				for (int i = 1; i < WL.length; i++) {
					if(WL[i][0] != WL[i][1]) {
						if(WL[i][0] == true) {
							minMax[1] = A[i];
						}
						else {
							minMax[0] = A[i];
						}
					}
				}
			
			for (int i = 1; i < A.length; i++) {
				System.out.printf("%7d ",A[i]);
			}
			System.out.println();
			for (int i = 1; i < WL.length; i++) {
				System.out.printf("%7s ",WL[i][0]);
			}
			System.out.println();
			for (int i = 1; i < WL.length; i++) {
				System.out.printf("%7s ",WL[i][1]);
			}
			System.out.println();
		}
		else {
			System.out.println("Wrong Input!!!! Minimum 2 and even numbers required");
		}
		return minMax;
	}

}
