// CS-404, k-Clique Backtracking
// Bhumit Thakkar

import java.util.Scanner;

import java.io.*;
import java.util.Date;

public class Clique_Backtracking_BhumitThakkar
{

// The following method determines if there is a k-clique in undirected graph W by
// using backtracking.  It calls kCliqueRec with parameters n, k, W, and an additional 
// array called "vertices".  After the call to kCliqueRec is done, vertices[0] is set to 
// 1 if and only if there is a k-clique.  In this case, vertices[1], ..., vertices[n] are set to the 
// indices of the vertices in the FIRST k-clique found (in increasing order).
	
	static int temp = 0;								// Graph to execute
   public static void kClique(int n, int k, int [][] W, int [] vertices) {
	   temp++;
	   if(temp <= 7)									// after Graph 5, main[] stack get's too big for my memory
		   kCliqueRec(0, n, k, W, vertices);
   }
   
   
// The kCliqueRec method does the backtracking, using array "vertices" to keep track of which
// vertices are in the k-clique so far.  The indices in "vertices" must always be 
// in increasing order (or 0 points for this problem).  Once (if) a k-clique is found, no further
// searching for another k-clique is done (or 0 points for this problem).
   public static void kCliqueRec(int i, int n, int k, int [][] W, int [] vertices) {

//	   for (int j = 1; j < vertices.length; j++) {
//			System.out.print(vertices[j]+" ");
//	   }
//	   System.out.println();
	   boolean promising = promising(i, W, vertices);
	   if (promising) {
		   if(i == k) {
			   vertices[0] = 1;
			   return;
		   }
		   if( vertices[i] + 1 <= n-(k-(i+1)) ){
			   vertices[i+1] = vertices[i] + 1;
			   kCliqueRec(i+1, n, k, W, vertices);
		   }
	   }
	   else {
		   if(vertices[i] + 1 <= n-(k-i)){
			   vertices[i]++;
			   kCliqueRec(i, n, k, W, vertices);
		   }
		   else {
			   vertices[i] = 0;
			   int previous = i - 1;
			   if (previous >= 1) {
				   while(vertices[previous] + 1 > n-(k-previous)) {
					   vertices[previous] = 0;
					   previous--;
					   if(previous == 0) {
						   break;
					   }
				   }
				   if(previous>=1) {									// Might be updated in above for loop after entrance in if
					   vertices[previous]++;
					   kCliqueRec(previous, n, k, W, vertices);
				   }
			   }
		   }
	   }
   }
            
// The promising method for kCliqueRec:
   
   public static boolean promising(int i, int [][] W, int [] vertices)  {
	   if(i != 0) {
		   
		   // Part 1
		   for (int r = 1; r <= i - 1; r++) {
			   for (int c = r+1; c <= i; c++) {
				   if(W[vertices[r]][vertices[c]] == 0) {
					   return false;
				   }
			   }
		   }

		   // Part 2
		   int count = 0;
		   for (int r = vertices[i]+1; r < W.length; r++) {
			   if(W[vertices[i]][r] == 1) {
				   count++;
			   }
		   }
		   if(count < (vertices.length -1) - i) {
			   return false;
		   }
	   }
	   else
		   return true;
	   
	   return true;
   }
   
   
//====================================================================================================   
   

	public static void main(String[] args) throws IOException  {   
		
		Scanner kbd = new Scanner(System.in);
	      Scanner input;
	      
	      String inputFilePath = Clique_Backtracking_BhumitThakkar.class.getResource("graphs.txt").toString();
	      // If not in main use: this.getClass().getResource("words.txt");
	      inputFilePath = inputFilePath.replace("%20", " ");
	      inputFilePath = inputFilePath.replace("file:/", "");
//	      System.out.println(inputFilePath);
	      FileReader f = new FileReader(inputFilePath);
	      input = new Scanner(f);
	      
//      FileReader f = new FileReader("graphs.txt");
//      Scanner input = new Scanner(f);

      Date date;
      long start, end;
      int n, k;
      int [][] W;
      
      while (input.hasNext())  {
         n = input.nextInt();
         k = input.nextInt();
         W = getNextGraph(n, input);
         int [] vertices = new int[k+1];
      

         System.out.println("\nChecking for " + k + "-clique in graph with n = " + n + " vertices...");
         date = new Date();
         start = date.getTime();

         kClique(n, k, W, vertices);
         
         date = new Date();
         end = date.getTime();
         System.out.println("Done checking in:  " + (end - start) + " milliseconds.");

         
         if (vertices[0] == 1)  {
         
            System.out.print("This graph DOES INDEED have a " + k + "-clique:  ");
            printArray(k, vertices);
         }
         else  
            System.out.println("This graph does NOT have a " + k + "-clique.");

         
      
      }
   }
   

   public static void printArray(int k, int [] vertices)
   {
      for (int i = 1; i <= k; i++)
         System.out.print(vertices[i] + " ");
      System.out.println();
   }

   public static int [][] getNextGraph(int n, Scanner input)
   {
      int [][] W = new int[n+1][n+1];

      for (int i = 1; i <= n; i++) 
         for (int j = 1; j <= n; j++)
            W[i][j] = input.nextInt();
      
      return W;
   }



} // end class