// Bhumit Thakkar
// CS 404

package assignment8;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Prob123 {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner input;
		String inputFilePath = Prob123.class.getResource("formulas_asst8.txt").toString();
		// If not in main use: this.getClass().getResource("words.txt");
		inputFilePath = inputFilePath.replace("%20", " ");
		inputFilePath = inputFilePath.replace("file:/", "");
		// System.out.println(inputFilePath);
		FileReader f;
		f = new FileReader(inputFilePath);
		input = new Scanner(f);
		//    FileReader f = new FileReader("graphs.txt");
		//    Scanner input = new Scanner(f);
			      
		int n, k;
		int [][] F;
		int W[][];
		int count=1;
		int vertices[];
		boolean truthAsst[];
		while (input.hasNext())  {
			n = input.nextInt();
			k = input.nextInt();
			F = getNextGraph(k, input);
			W = new int[3*k + 1][3*k + 1];
			truthAsst = new boolean[n+1];
			vertices = new int[W.length];
			
			
			System.out.println("Formula "+ (count++) +", n = "+n+", k = "+k+":");
			W = reduce_3SAT_to_CLIQUE(n, k, F);												// call for Problem 2
			
			System.out.println("Checking for "+ k +"-clique in graph with n = "+3*k+" vertices...");
//			printArray(F.length, F);
//			printArray(W.length, W);
			Clique_Backtracking_SOLUTION.kClique(W.length - 1, k, W, vertices);					// call for k-clique
			if(vertices[0] == 1) {
				System.out.print("This graph DOES INDEED have a "+k+"-clique:");
				printArray(k, vertices);
				truthAsst = getAsstFromClique(n, k, vertices, F);							// call for Problem 3
				System.out.println("The satisfying assignment to the formula is:");
				System.out.print("Assignment:  ");
				for (int i = 1; i < truthAsst.length; i++) {
					System.out.print("x_{"+i+"} = "+truthAsst[i]);
					if(i != truthAsst.length-1)
						System.out.print(", ");
				}
				System.out.println();
				System.out.print("Calling \"evaluate\"...");
				if(evaluate(n, k, F, truthAsst)) {											// call for Problem 1
					System.out.println("This formula IS SATISFIED by this assignment!");
				}
				else {
					System.out.println("This formula is NOT satisfied by this assignment!");
				}
			}
			else {
				System.out.println("This graph does NOT have a "+k+"-clique. So can't have a truthAsst for this formulae");
			}
			
			System.out.println();
		}
		
	}
	
	public static int [][] reduce_3SAT_to_CLIQUE(int n, int k, int [][] F){
		int W[][] = new int [3*k + 1][3*k + 1];
		for(int i=1; i<W.length; i++) {
			int Frow_i = i/3 + 1;
			int Fcol_i = i%3;
			if(i%3 == 0) {
				Frow_i--;
				Fcol_i = 3;
			}
			for(int j=i+1; j<W[i].length; j++) {
				int Frow_j = j/3 + 1;
				int Fcol_j = j%3;
				if(j%3 == 0) {
					Frow_j--;
					Fcol_j = 3;
				}
				
				if(Frow_i == Frow_j) {
					W[i][j] = 0;
					W[j][i] = 0;
				}
				else if(F[Frow_i][Fcol_i] == -1 * F[Frow_j][Fcol_j]) {
					W[i][j] = 0;
					W[j][i] = 0;
				}
				else {
					W[i][j] = 1;
					W[j][i] = 1;
				}
			}
		}
		return W;
	}
	
	public static boolean [] getAsstFromClique(int n, int k, int [] kClique, int [][] F) {
		boolean truthAsst[] = new boolean[n+1];
		for(int i = 1; i<=k; i++) {
			int Frow = kClique[i] / 3 + 1;
			int Fcol = kClique[i] % 3;
			if(Fcol % 3 == 0) {
				Frow--;
				Fcol = 3;
			}
			if(F[Frow][Fcol] < 0) {
				truthAsst[ F[Frow][Fcol]*-1 ] = false;
			}
			else {
				truthAsst[ F[Frow][Fcol] ] = true;
			}
		}
		return truthAsst;
	}
	
	public static boolean evaluate(int n, int k, int [][] F, boolean [] truthAsst) {
		boolean formulae = true;
		for(int i = 1; i<F.length; i++) {
			boolean row_i = false;
			for(int j = 1; j<4; j++) {
				if(F[i][j] < 0) {
					if(! truthAsst[ -1*F[i][j] ] ) {
						row_i = true;
						break;
					}
				}
				else {
					if(truthAsst[ F[i][j] ]) {
						row_i = true;
						break;
					}
				}
			}
			if(row_i == false) {
				formulae = false;
				break;
			}
		}
		return formulae;
	}
	
	public static void printArray(int n, int W[][]){
	      for (int i = 1; i < n; i++) {
	          for (int j = 1; j < W[i].length; j++)
	             System.out.printf("%5d", W[i][j]);
	          System.out.println();
	      }
	      
	      System.out.println();
	      System.out.println();
	}
	
	public static void printArray(int k, int [] vertices)
	   {
	      for (int i = 1; i <= k; i++)
	         System.out.print(vertices[i] + " ");
	      System.out.println();
	   }

	public static int [][] getNextGraph(int n, Scanner input){
      int [][] F = new int[n+1][4];
      for (int i = 1; i <= n; i++) 
         for (int j = 1; j < F[i].length; j++)
            F[i][j] = input.nextInt();
      
      return F;
	}

}
