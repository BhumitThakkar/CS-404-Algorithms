package assignment6;

public class IntQueue 
{
	private int rear;
	private int front;
	private int maxSize;
	private int IntQueue[];
	
	public IntQueue()
	  {
		  rear = 1;
		  front = 1;
		  maxSize = 50;
		  IntQueue = new int[maxSize];
	  }
	
	  public IntQueue(int n)						// Adding for "Custom Size Queue Constructor"
	  {
		  rear = 1;
		  front = 1;
		  maxSize = n+1;
		  IntQueue = new int[maxSize];
	  }

	  public void enqueue(int element)
	  // Adds element to the rear of this queue.
	  {
		  if(element > 0 && rear != maxSize){	// node can't be 0 or negative |&| node can be inserted only if queue has space(CONSIDERING THIS IS NOT A CIRCULAR QUEUE)
			  IntQueue[rear++] = element;
		  }
	  }
	
	  public int dequeue()
	  // Removes front element from this queue and returns it.
	  {
		  if(front < maxSize) {
			  if(IntQueue[front] != 0)
				  return IntQueue[front++];
			  else
				  return -1;						// No more element or vertex
		  }
		  
		  return -1;
	  }
	
	  public boolean isEmpty()
	  // Returns true if this queue is empty; otherwise, returns false.
	  {              
		  boolean isEmpty = false;
		  if(front == rear) {
			  isEmpty = true;
		  }
	      return isEmpty;
	  }
	  
}

