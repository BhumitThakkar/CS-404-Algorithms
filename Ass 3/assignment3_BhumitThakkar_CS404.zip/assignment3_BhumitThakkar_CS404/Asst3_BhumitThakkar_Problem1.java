// !!!!!!!!!!!!!!!BHUMIT THAKKAR!!!!!!!!!!!!!!!!!!!!!!
//
// Assignment 3, CS-404, Fall 2019

package assignment3;

public class Asst3_BhumitThakkar_Problem1 {

	public static void main(String[] args) {
		System.out.println("Bhumit Thakkar");
		System.out.println("CS404: Assignment 3 : Problem 1");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		Asst3_BhumitThakkar_Problem1 p1 = new Asst3_BhumitThakkar_Problem1();
		int n = 15;
		int k = 5;
		int answer = p1.combin(n, k);
		System.out.println(n+" Choose "+k+" = "+ answer);
	}
	
	int combin(int n, int k) {
		int answer = -1;
		int currentArray[] = new int[k+1];
		int previousArray[] = new int[k+1];
		int next;
		if(n>=k) {
			if(n == k || k == 0) {
				answer = 1;
			}
			else {
				for(int i=0;i<=n;i++) {
					next = 0;
					for(int j=0;j<=k;j++) {
						if(i == j) {
							currentArray[next++] = 1;
							break;
						}
						else if(j == 0){
							currentArray[next++] = 1;
						}
						else {
							currentArray[next] = previousArray[next] + previousArray[next - 1];
							next++;
						}
					}
					// Copy currentArray into previousArray except the last n
					if(i != n) {
						for (int i1 = 0; i1 < previousArray.length; i1++) {
							previousArray[i1] = currentArray[i1];
						}
					}
				}
				answer = currentArray[k];
			}
		}
		return answer;
	}
	
}
