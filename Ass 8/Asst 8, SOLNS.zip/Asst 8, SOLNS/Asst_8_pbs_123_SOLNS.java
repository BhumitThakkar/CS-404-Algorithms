import java.util.Scanner;
import java.io.*;    

public class Asst_8_pbs_123_SOLNS
{
	public static void main(String[] args) throws IOException  {
    
      FileReader f = new FileReader("formulas_asst8.txt");
      Scanner input = new Scanner(f);
      int n, k, i = 0;
      int [][] F;
      int [][] W;
      boolean [] asst;       
      int [] clique;
     
      while (input.hasNext())  {

         i++;
         n = input.nextInt();
         k = input.nextInt();
         F = getNextFormula(k, input);
         asst = new boolean[n+1];         
                   
         System.out.println("\nFormula " + i + ", n = " + n + ", k = " + k + ": ");
         
         W = reduce_3SAT_to_CLIQUE(n, k, F);
         
         int numNodes = W.length - 1;
         clique = new int[k+1];

         System.out.println("Checking for " + k + "-clique in graph with n = " + numNodes + " vertices...");
         kClique(numNodes, k, W, clique);
         
         if (clique[0] == 1)  {
         
            System.out.print("This graph DOES INDEED have a " + k + "-clique:  ");
            printArray(k, clique);
            System.out.println("\nFrom the clique, the satisfying assignment to the formula is:  ");
            asst = getAsstFromClique(n, k, clique, F);        
            printAsst(n, asst);
            boolean result = evaluate(n, k, F, asst);
            if (result)
               System.out.println("Formula F DOES evaluate to TRUE with this assignment.\n");
            else  {
               System.out.println("Formula F evalutes to FALSE with this assignment!");
               System.out.println("SOMETHING IS WRONG HERE.....\n");
            }           
         }
         else  
            System.out.println("This graph does NOT have a " + k + "-clique.\n");
            

      }
   }
   
//========================================================================

   public static boolean evaluate(int n, int k, int [][] F, boolean [] truthAsst)  {
   
      int badCount;
      
      for (int j = 1; j <= k; j++)  {
      
         badCount = 0;
         for (int col = 1; col <= 3; col++)
         {
            int var = Math.abs(F[j][col]);
            
            if (truthAsst[var]  && F[j][col] < 0)
               badCount++;
            else if (!truthAsst[var] && F[j][col] > 0)
               badCount++;
         }
         
         if (badCount == 3)
            return false;
      }
      
      return true;
   }

//========================================================================
// Take boolean formula and return graph W such that F is satisfiable iff W has a k-clique


   public static int [][] reduce_3SAT_to_CLIQUE(int n, int k, int [][] F)  {

      int numNodes = 3*k;
      int [][] W = new int[numNodes+1][numNodes+1];

      for (int i = 1; i <= numNodes; i++)
         for (int j = 1; j <= numNodes; j++)  {
            
            int a = (i-1) / 3  + 1;
            int b = (i-1) % 3  + 1;
            int c = (j-1) / 3  + 1;
            int d = (j-1) % 3  + 1;
            
//            System.out.println("(a,b) = " + a + ", " + b + ", (c,d) = " + c + ", " + d);
            
            if (a != c  &&  F[a][b] != -F[c][d])
               W[i][j] = 1;
      }
      return W;
   }
   
//========================================================================

   public static void printW(int n, int [][] W) {
      
      for (int i = 1; i <= n; i++) {
         for (int j = 1; j <= n; j++)
            System.out.print(W[i][j]);
         System.out.println();
      }
   }
   
   
//========================================================================

   public static boolean [] getAsstFromClique(int n, int k, int [] clique, int [][] F)  {
   
      boolean [] asst = new boolean[n+1];
      
      for (int i = 1; i <= k; i++)  {
      
         int row = (clique[i] - 1) / 3  + 1;
         int col = (clique[i] - 1) % 3  + 1;
         
         int var = Math.abs(F[row][col]);
         
         asst[var] = F[row][col] > 0 ?  true : false;
      }
      
      return asst;
   }
   
   
   
//========================================================================


// If formula F is NOT satisfiable, then "satisfy" returns false.
// If formula F IS satisfiable, then truthAsst contains a satisfying assignment, with truthAsst[i] = 1 
// if variable x_{i} is true, and 0 if false, and the method returns true.
// This method calls satisfyRec.

   public static boolean satisfy(int n, int k, int [][] F, int [] truthAsst)  {
   
      satisfyRec(0, n, k, F, truthAsst);
      
      return (truthAsst[0] == 1);
   }
   
//========================================================================

// This method does the backtracking to search for a satisfying truth assignment.  
// Once (if) it finds a satisfying truth assignment, it does not search for another one (0 points if you do).
   
   public static void satisfyRec(int i, int n, int k, int [][] F, int [] truthAsst)
   {
      if (promising(i, k, F, truthAsst))
      {
         if (i == n)
            truthAsst[0] = 1;

         else
         {
            for (int b = -1; b < 2 && truthAsst[0] == 0; b += 2)
            {
               truthAsst[i+1] = b;
               satisfyRec(i+1, n, k, F, truthAsst);
            }
         }
      }
   }
            
//========================================================================
// The promising method for satisfyRec:

   public static boolean promising(int i, int k, int [][] F, int [] truthAsst)
   {
      int badCount;
      for (int j = 1; j <= k; j++)
      {
         badCount = 0;
         
         for (int col = 1; col <= 3; col++)
         {
            int var = Math.abs(F[j][col]);
            if (var > i)
               break;
            else if (truthAsst[var] > 0 && F[j][col] < 0)
               badCount++;
            else if (truthAsst[var] < 0 && F[j][col] > 0)
               badCount++;
         }
         
         if (badCount == 3)
            return false;
      }
      
      return true;
   }


//========================================================================
// The following method determines if there is a k-clique in undirected graph W by
// using backtracking.  It calls kCliqueRec with parameters n, k, W, and an additional 
// array called "vertices".  After the call to kCliqueRec is done, the array "vertices" is set as follows:
// If there is a k-clique in W, then vertices[0] is 1, and vertices[1], ..., vertices[n] are set to the 
// indices of the vertices in the FIRST k-clique found (in increasing order).

   public static void kClique(int n, int k, int [][] W, int [] vertices) {

      kCliqueRec(0, n, k, W, vertices); 
   }
   
//========================================================================
   
// The kCliqueRec method does the backtracking, using array "vertices" to keep track of which
// vertices are in the k-clique so far.  The indices in "vertices" must always be 
// in increasing order (or 0 points for this problem).  Once (if) a k-clique is found, no further
// searching for another k-clique is done (or 0 points for this problem).
   
   public static void kCliqueRec(int i, int n, int k, int [][] W, int [] vertices)
   {
      if (promising(i, W, vertices))
      {
         if (i == k)
            vertices[0] = 1;

         else
         {
            for (int b = vertices[i] + 1; b <= n && vertices[0] == 0; b++)
            {
               vertices[i+1] = b;
               kCliqueRec(i+1, n, k, W, vertices);
            }
         }
      }
   }

//========================================================================
            
// The promising method for kCliqueRec:
   
   public static boolean promising(int i, int [][] W, int [] vertices)
   {
      for (int j = 1; j < i; j++)
         if (W[vertices[i]][vertices[j]] != 1)
            return false;
      return true;
   }
//========================================================================

   
   public static void printArray(int k, int [] vertices)
   {
      for (int i = 1; i <= k; i++)
         System.out.print(vertices[i] + " ");
      System.out.println();
   }

   public static void printArray(int n, boolean [] A) {
      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
      System.out.println();
   }


   public static void printFormula(int k, int [][] F)  {
   
      for (int i = 1; i <= k; i++)  {
      
         for (int j = 1; j <= 3; j++)
            System.out.print(F[i][j] + " ");
         System.out.println();
      }

   }
   
   public static void printAsst(int n, boolean [] truthAsst)
   {
      System.out.print("Assignment:  ");
      for (int i = 1; i <= n - 1; i++)
      {
         System.out.print("x_{" + i + "} = " + truthAsst[i] + ", ");
      }
      
      System.out.print("x_{" + n + "} = " + truthAsst[n]);

      System.out.println();
   }

   
   public static int [][] getNextFormula(int k, Scanner input)
   {
      int [][] F = new int[k+1][4];

      for (int i = 1; i <= k; i++) 
         for (int j = 1; j <= 3; j++)
            F[i][j] = input.nextInt();
      
      return F;
   }
   
      


} // end class