// CS-404, Fall 2019, Assignment 2 Template
// BHUMIT THAKKAR
// EACH AND EVERY PROGRAM IS TESTED - IF ANY OF THEM NOT RUNNING IN YOUR PC, PLEASE LET ME KNOW
// THANKYOU
		
import java.math.BigInteger;
import java.util.Random;
import java.util.Scanner;



public class CS_404_Asst2_template_updated { 

//////////////////////////////////////////////////////////////////////
// Problem 1

public static int numWaysChange (int n, int k, int [] D) {
	int numWays = 0;
	if(n<0) {
		return 0;
	}
	else if(n == 0 || k == 1) {
		return 1;
	}
	else {
		numWays = numWaysChange(n - D[k-1], k, D) + numWaysChange(n, k-1, D);
	}
	return numWays;
}

//////////////////////////////////////////////////////////////////////
// Problem 2

public static int binarySearch(int [] A, int low, int high, int x)  {
	// Assuming A is sorted and it contains minimum 1 element
	// Assuming provided low <= high
	// Assuming low>=0 and high<A.length
	int m_index = (low+high)/2;
	if(low == high) {
		if(A[low] == x) {
			return low;
		}
		else {
			return -1;
		}
	}
	else {
		if(A[m_index] >= x) {
			m_index = binarySearch(A, low, m_index, x);
		}
		else {
			m_index = binarySearch(A, m_index+1, high, x);
		}
	}
	return m_index;
}

//////////////////////////////////////////////////////////////////////
// Problem 3

public static int partition(int [] A, int low, int high)  {
	// Assuming A contains minimum 1 element
	// Assuming provided low <= high
	// Assuming low>=0 and high<A.length
	int swapIndex = low;
	int temp;
	for(int i=low+1; i<=high; i++) {
		if(A[low]<=A[i]) {
			continue;
		}
		else {										// Brings lower value on left most part of right side of A[low].
			if(++swapIndex != i) {					// So that it won't exchange with itself.
				temp = A[swapIndex];
				A[swapIndex] = A[i];
				A[i] = temp;
			}
		}
	}
	if(swapIndex != low) {							// Final swap that makes left part lower than right part of pivot
		temp = A[swapIndex];
		A[swapIndex] = A[low];
		A[low] = temp;
	}
	return swapIndex;
}
         
//////////////////////////////////////////////////////////////////////
// Problem 4

public static int indexOfMinElt(int [] A, int low, int high)  {
	// Assuming A contains minimum 1 element
	// Assuming provided low <= high
	// Assuming low>=0 and high<A.length
	int minIndex = -1;
	if(low == high) {
		return low;
	}
	else {
		int minIndex1 = indexOfMinElt(A, low, (low+high)/2);
		int minIndex2 = indexOfMinElt(A, ((low+high)/2) + 1, high);
		minIndex = (A[minIndex1]<=A[minIndex2]?minIndex1:minIndex2);
	}
	return minIndex;
}
/* Running Time
 * T(1) = c1
 * T(n) = 2T(n/2) + c2
 *      = 2 x (2T(n/4) + c2) + c2 = 4T(n/4) + 3c2
 *      = 4 x (2T(n/8) + c2) + 3c2 = 8T(n/8) + 7c2
 *      .
 *      .
 *      .
 *      = (2^k).T(n/2^k) + (2^k - 1)c2
 *      
 *      for T(1); n = 2^k
 *      = n.c1 + (n-1)c2
 *      = O(n)      ----------------------------------> Running Time
 * */

         
//////////////////////////////////////////////////////////////////////
// Problem 5

public static void sortRec(int [] A, int low, int high)  {
	// Assuming A contains minimum 1 element
	// Assuming provided low <= high
	// Assuming low>=0 and high<A.length
	if(low != high) {
		int minIndex = Problem4.indexOfMinElt(A, low, high);
		if(low != minIndex) {
			int temp = A[low];
			A[low] = A[minIndex];
			A[minIndex] = temp;
		}
		sortRec(A, low+1, high);
	}
}
/* Running Time
 * T(1) = c1
 * T(n) = O(n) + T(n-1) + c2
 *      = O(n) + [ O(n-1) + T(n-2) + c2] + c2 = 2.O(n) + T(n-2) + 2.c2
 *      .
 *      .
 *      .
 *      .
 *      = k.O(n) + T(n-k) + k.c2
 *      
 *      for T(1); n = k
 *      = n.O(n) + T(1) + n.c2
 *      = O(n^2) + c1 + O(n)
 *      = O(n^2)      ----------------------------------> Running Time
 * */

//////////////////////////////////////////////////////////////////////
// Problem 6
/*

>>>>>>>>>>>>>>>TRY1<<<<<<<<<<<<<
123 --- 456 | 789
if 123 heavier 123 - counterfeit group
if 456 heavier 456 - counterfeit group
if both equal 789 - counterfeit group

>>>>>>>>>>>>>>>TRY2<<<<<<<<<<<<<
for eg if 789 is counterfeit group
7 --- 8 | 9
if 7 heavier 7 - counterfeit coin
if 8 heavier 8 - counterfeit coin
if both equal 9 - counterfeit coin
-------------------------------------------------
Explaination:

No of counterfeit coin = 1.
So for last try I need to balance 2 coins out of 3 probable faulty coins. Whichever heavier is counterfeit or else(if both same weight) the remaining of them which was not weighted is counterfeit.
So before my second try : I need pair of 3 coins that will have 1 coin faulty.

Max try = 2
So in the end of 1st try we need group of 3 coins that has 1 counterfeit coin.
We can weight 2 groups of 3 coins and if any side goes heavier,it is the counterfeit group or else(if both same weight) the one not weighted is counterfeit group.


*/


//////////////////////////////////////////////////////////////////////
// Problem 7
/*

Algorithm in words("Technique/Logic")
 * 
 * For n(Some power of 3), every time we need to divide our n terms by 3 times to run in Log3(n)
 * 
 * And we can do it.
 * 
ALGORITHM In Words(Explaination of the flow):

EVERY TIME IT WILL CONTINUE DIVIDING INTO 3 TIMES LESSER TERMS(Considered n as power of 3)
 * 1st n/3 term <--WEIGHT VS--> 2nd n/3 terms | 3rd n/3 terms (Stand By)
 * If 1st n/3 term is higher - we got the 1st group with counterfeit coin.
 * If 2nd n/3 term is higher - we got the 2nd group with counterfeit coin.
 * If both group are equal - we got the 3rd group with counterfeit coin.
 * {Implemented in recursive call in problem 13}
 * 
 * It goes on dividing and will reach to a point of 3 single coins : 1 vs 2 | 3
 * 1 <--WEIGHT VS--> 2 | 3 (Stand By)
 * If 1 is higher - we got the 1st coin as counterfeit coin.
 * If 2 is higher - we got the 2nd coin as counterfeit coin.
 * If both group are equal - we got the 3rd coin as counterfeit coin.
 * 
 * 
BaseCase: Single coin to be counterfeit and returning that faulty one.
 * 
 * 
IMPLEMENTED and TESTED Problem13.
 * 
 * 
RUNNING TIME:
 * 
 * Its similar like binary search, we were dividing our list into 2 pieces and we were only concerned about 1 piece resulting in Log2(n)
 * Here we are dividing our n terms into n/3 at every iteration and are again only concerned about the single counterfeit group. resulting in Log3(n)
 * 

*/

//////////////////////////////////////////////////////////////////////
// Problem 8

public static double average(double [] A, int low, int high)  {
	// Assuming A contains minimum 1 element
	// Assuming provided low <= high
	// Assuming low>=0 and high<A.length
	double avg = 0;
	if(low == high) {
		return A[low];
	}
	else {
		avg = average(A, low+1, high) + ( (A[low] - average(A, low+1, high)) / (high-low+1) );
	}
	return avg;
}

//////////////////////////////////////////////////////////////////////
// Problem 9 (PROGRAM & ALGO - BOTH )

// PROGRAM
public static BigInteger prod(BigInteger u, BigInteger v)  {
	// Assuming u & v >= 0;
	BigInteger TEN = new BigInteger("10");
	BigInteger ONE = new BigInteger("1");
	BigInteger p,q,r,x,y,w,z;
	BigInteger MULT = ONE;
	int n,m;
	if(u.compareTo(v) >= 0) {
		n = u.toString().length();			
	}
	else{
		n = v.toString().length();
	}
	if(n == 1) {
		return u.multiply(v);
	}
	else {
		m = n/2;
		x = u.divide(TEN.pow(m));
		y = u.mod(TEN.pow(m));
		w = v.divide(TEN.pow(m));
		z = v.mod(TEN.pow(m));

		p = prod(x,w);
		q = prod(y,z);
		r = prod(x.add(y),w.add(z));
		System.out.println("u="+u+" v="+v+" x="+x+" y="+y+" w="+w+" z="+z+" n="+n+" m="+m+" p="+p+" q="+q+" r="+r);
		
		BigInteger FirstTerm = p.multiply(TEN.pow(2*m));
		BigInteger SecondTerm = (r.subtract(p).subtract(q)).multiply(TEN.pow(m));
		BigInteger ThirdTerm = q;

		MULT = FirstTerm.add(SecondTerm).add(ThirdTerm );
	}
	return MULT;
}

// Algorithm
/*
procedure prod(BigInteger u, BigInteger v) {
	// Assuming u & v >= 0;
	
	BigInteger p,q,r,x,y,w,z;
	int n,m;
	
	n = max(u.length,v.length);
	
	if(n == 1) {
		return u * v;
	}
	else {
		m = n/2;
		x = u / 10^m;
		y = u % 10^m;
		w = v / 10^m;
		z = v % 10^m;
	
		p = prod(x,w);
		q = prod(y,z);
		r = prod(x+y,w+z);
		
		BigInteger FirstTerm = p*(10^2m) ;
		BigInteger SecondTerm = (r-p-q)*(10^m);
		BigInteger ThirdTerm = q;
	
		return FirstTerm+SecondTerm+ThirdTerm;
	}
}
*/

//////////////////////////////////////////////////////////////////////
// Problem 10
// Trace through prod(2132, 1345):

/*
 * Answer 10: Product is 2867540. There are 11 single digit multiplications.


------------------------------------------
Call 1: prod(2132,1345)
n = 4
m = 2
x = 21
y = 32
w = 13
z = 45
r = prod(x+y, w+z)
  = prod(53, 58)
  = __3074__ (CALL 2)
p = prod(x,w)
  = prod(21,13)
  = __273__ (CALL 3)
q = prod(y,z)
  = prod(32,45)
  = __1440__ (CALL 4)
  return (p)x10^4 + [(r-p-q)x10^2] + (q)
         = 2730000 + 136100 + 1440
         = 2867540
------------------------------------------
Call 2: prod(53,58)
n = 2
m = 1
x = 5
y = 3
w = 5
z = 8
r = prod(x+y, w+z)
  = prod(8, 13)
  = __104__ (CALL 5)
p = prod(x,w)
  = prod(5,5)
  = __25__ (CALL 6)
q = prod(y,z)
  = prod(3,8)
  = __24__ (CALL 7)
  return (p)x10^2 + [(r-p-q)x10^1] + (q)
         = 2500 + 550 + 24
         = 3074
------------------------------------------
Call 3: prod(21,13)
n = 2
m = 1
x = 2
y = 1
w = 1
z = 3
r = prod(x+y, w+z)
  = prod(3, 4)
  = __12__ (CALL 8)
p = prod(x,w)
  = prod(2,1)
  = __2__ (CALL 9)
q = prod(y,z)
  = prod(1,3)
  = __3__ (CALL 10)
  return (p)x10^2 + [(r-p-q)x10^1] + (q)
         = 200 + 70 + 3
         = 273
------------------------------------------
Call 4: prod(32,45)
n = 2
m = 1
x = 3
y = 2
w = 4
z = 5
r = prod(x+y, w+z)
  = prod(5, 9)
  = __45__ (CALL 11)
p = prod(x,w)
  = prod(3,4)
  = __12__ (CALL 12)
q = prod(y,z)
  = prod(2,5)
  = __10__ (CALL 13)
  return (p)x10^2 + [(r-p-q)x10^1] + (q)
         = 1200+230+10
         = 1440
------------------------------------------
Call 5: prod(8,13)
n = 2
m = 1
x = 0
y = 8
w = 1
z = 3
r = prod(x+y, w+z)
  = prod(8, 4)
  = __32__ (CALL 14)
p = prod(x,w)
  = prod(0,1)
  = __0__ (CALL 15)
q = prod(y,z)
  = prod(8,3)
  = __24__ (CALL 16)
  return (p)x10^2 + [(r-p-q)x10^1] + (q)
         = 0 + 80 + 24
         = 104
------------------------------------------
Call 6: prod(5,5)
n = 1
retrun 5x5 = 25;
------------------------------------------
Call 7: prod(3,8)
n = 1
retrun 3x8 = 24;
------------------------------------------
Call 8: prod(3,4)
n = 1
retrun 3x4 = 12;
------------------------------------------
Call 9: prod(2,1)
n = 1
retrun 2x1 = 2;
------------------------------------------
Call 10: prod(1,3)
n = 1
retrun 1x3 = 3;
------------------------------------------
Call 11: prod(5,9)
n = 1
retrun 5x9 = 45;
------------------------------------------
Call 12: prod(3,4)
n = 1
retrun 3x4 = 12;
------------------------------------------
Call 13: prod(2,5)
n = 1
retrun 2x5 = 10;
------------------------------------------
Call 14: prod(8,4)
n = 1
retrun 8x4 = 32;
------------------------------------------
Call 15: prod(0,1)
n = 1
retrun 0x1 = 0;
------------------------------------------
Call 16: prod(8,3)
n = 1
retrun 8x3 = 24;

*/

//////////////////////////////////////////////////////////////////////
// Problem 11

public static int combinations(int n, int k)  {
	if(n<k) {
		return -1;
	}
	if(k == 0) {
		return 1;
	}
	else if(n==k) {
		return 1;
	}
	else {
		return combinations(n-1, k-1) + combinations(n-1, k); 
	}
}

   
//////////////////////////////////////////////////////////////////////
// Problem 12

public static int [] closestPair(int n, Point [] Q) {
	int [] ans = {-1, -1};
	if(n<=1) {
		ans[0] = -1;
		ans[1] = -1;
		return ans;
	}
	double x_distance = Q[0].x - Q[1].x;
	double y_distance = Q[0].y - Q[1].y;
	double minDist = Math.sqrt( x_distance*x_distance + y_distance*y_distance );
	for(int i=1;i<=n-2;i++) {
		for(int j=i+1;j<=n-1;j++) {
			x_distance = Q[i].x - Q[j].x;
			y_distance = Q[i].y - Q[j].y;
			double Dist = Math.sqrt( x_distance*x_distance + y_distance*y_distance );
			System.out.println("i="+Q[i]+" j="+ Q[j] +" dist="+ Dist);
			if(Dist < minDist) {
				minDist = Dist;
				ans[0] = i+1;
				ans[1] = j+1;
			}
		}
	}
	return ans;
}


//////////////////////////////////////////////////////////////////////
// Problem 13

public static int counterfeit(int n) {
	int counterfeit = -1;
	  if(low == high) {
  	  return low;
    }
    else {
  	  int low1=low;
  	  int high1=low1 + (high-low)/3;
  	  
  	  int low2=high1+1;
  	  int high2=low2 + (high-low)/3;
  	  
  	  int low3=high2+1;
  	  int high3=low3 + (high-low)/3;
  	  
  	  System.out.println(low1+"..."+high1+"|"+low2+"..."+high2+"|"+low3+"..."+high3);
  	  
  	  int balance = balance(low1, high1, low2, high2);
  	  
  	  if(balance == 1) {
  		  counterfeit = counterfeit(low1,high1);
  	  }
  	  else if(balance == 2) {
  		  counterfeit = counterfeit(low2,high2);
  	  }
  	  else {
  		  counterfeit = counterfeit(low3, high3);
  	  }
    }
	return counterfeit;
}
  
//////////////////////////////////////////////////////////////////////
// Testing

public static void main(String [] args){

	System.out.println("\nProblem 13\n");
	   
    System.out.println("The counterfeit coin is coin # " + counterfeit(1, 1));
    System.out.println();
    System.out.println();
    System.out.println("The counterfeit coin is coin # " + counterfeit(1, 3));
    System.out.println();
    System.out.println();
    System.out.println("The counterfeit coin is coin # " + counterfeit(1, 9));
    System.out.println();
    System.out.println();
    System.out.println("The counterfeit coin is coin # " + counterfeit(1, 27));
    System.out.println();
    System.out.println();
}

public static int balance(int low1, int high1, int low2, int high2) {

   Scanner kbd = new Scanner(System.in);

   System.out.print("Enter 1, 2, or 0:  ");
   return kbd.nextInt();
}


/*
 * 
 * I DO NOT NEED ANY OTHER EXTERNAL FUNCTIONS.
 * NEEDED FUNCTIONS ARE IMPLEMENTED WITHIN MY METHODS
 * 
 * 
public static void printArray(int n, int [] A) {
   
   for (int i = 1; i <= n; i++)
      System.out.print(A[i] + " ");
   System.out.println();
}

public static void swap(int [] A, int i, int j) {
   
   int temp = A[i];
   A[i] = A[j];
   A[j] = temp;
}

public static int numDigits(BigInteger u) {

   return u.toString().length();
}
*/



} // end class
