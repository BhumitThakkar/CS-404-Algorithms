// CS-404, k-Clique Backtracking

import java.util.Scanner;
import java.io.*;  
import java.util.Date;

public class Clique_Backtracking_YOURNAME
{

// The following method determines if there is a k-clique in undirected graph W by
// using backtracking.  It calls kCliqueRec with parameters n, k, W, and an additional 
// array called "vertices".  After the call to kCliqueRec is done, vertices[0] is set to 
// 1 if and only if there is a k-clique.  In this case, vertices[1], ..., vertices[n] are set to the 
// indices of the vertices in the FIRST k-clique found (in increasing order).

   public static void kClique(int n, int k, int [][] W, int [] vertices) {



   }
   
   
// The kCliqueRec method does the backtracking, using array "vertices" to keep track of which
// vertices are in the k-clique so far.  The indices in "vertices" must always be 
// in increasing order (or 0 points for this problem).  Once (if) a k-clique is found, no further
// searching for another k-clique is done (or 0 points for this problem).
   
   public static void kCliqueRec(int i, int n, int k, int [][] W, int [] vertices) {






   }
            
// The promising method for kCliqueRec:
   
   public static boolean promising(int i, int [][] W, int [] vertices)  {
   





      return false;
   }
   
   
//====================================================================================================   
   

	public static void main(String[] args) throws IOException  {    
   
      FileReader f = new FileReader("graphs.txt");
      Scanner input = new Scanner(f);

      Date date;
      long start, end;
      int n, k;
      int [][] W;
      
      while (input.hasNext())  {
      
         n = input.nextInt();
         k = input.nextInt();
         W = getNextGraph(n, input);
         int [] vertices = new int[k+1];
      

         System.out.println("\nChecking for " + k + "-clique in graph with n = " + n + " vertices...");
         date = new Date();
         start = date.getTime();

         kClique(n, k, W, vertices);
         
         date = new Date();
         end = date.getTime();
         System.out.println("Done checking in:  " + (end - start) + " milliseconds.");

         
         if (vertices[0] == 1)  {
         
            System.out.print("This graph DOES INDEED have a " + k + "-clique:  ");
            printArray(k, vertices);
         }
         else  
            System.out.println("This graph does NOT have a " + k + "-clique.");

         
      
      }
   }
   

   public static void printArray(int k, int [] vertices)
   {
      for (int i = 1; i <= k; i++)
         System.out.print(vertices[i] + " ");
      System.out.println();
   }

   public static int [][] getNextGraph(int n, Scanner input)
   {
      int [][] W = new int[n+1][n+1];

      for (int i = 1; i <= n; i++) 
         for (int j = 1; j <= n; j++)
            W[i][j] = input.nextInt();
      
      return W;
   }



} // end class