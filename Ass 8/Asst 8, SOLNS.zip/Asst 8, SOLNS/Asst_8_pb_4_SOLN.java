import java.util.Scanner; 
import java.util.Random;

public class Asst_8_pb_4_SOLN
{
   public static int [] reduce_SOS_to_PARTITION(int n, int [] A, int g)  {
   
      int i, sum = 0;
      
      int [] B = new int[n+3];  // in order to index B from 1 to (n+2)
      
      for (i = 1; i <= n; i++)  {
         B[i] = A[i];
         sum += A[i];
      }
      
      B[n+1] = sum + g;
      B[n+2] = 2*sum - g;
      
      return B;
   }

//========================================================================

	public static void main(String[] args)  {
   
      Random rand = new Random();
      Scanner kbd = new Scanner(System.in);
      int testAgain = 1;
      int n, i, g;
      int A [], B [];
      
      
      System.out.println();
      
      while (testAgain != 0) {
         
         n = rand.nextInt(3) + 4;
         A = new int[n+1];
         
         g = 0;
         for (i = 1; i <= n; i++) {
         
            A[i] = rand.nextInt(25) + 1;
            if (rand.nextDouble() > .5)
               g += A[i];
         }
            
         g += rand.nextInt(3); // adds 0, 1, or 2 to goal
      
         System.out.println("SUM-OF-SUBSET instance:  ");
         System.out.println("Goal g = " + g);
         System.out.print("Array A = [ ");
         printArray(n, A);
         System.out.println("]\n"); 

         B = reduce_SOS_to_PARTITION(n, A, g);
         
         System.out.println("Tranformed to SET-PARTITION: ");
         System.out.print("Array B = [ ");
         printArray(n+2, B);
         System.out.println("]\n"); 
         
         System.out.print("Enter 1 to test again, 0 to quit:  ");
         testAgain = kbd.nextInt();
         System.out.println("\n");
      }
   }
   
//========================================================================

   public static void printArray(int n, int [] A) {
      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
   }



} // end class