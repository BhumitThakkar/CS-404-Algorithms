//////////////////////////////////////////////////////////////////////
// Problem 1 - O(n)

int [] twoElementSum(int n, int [] A, int g)
{
	int Ans[] = new int[]{-1,-1};
	if(n>=2) {							// Array size should be atleast 2 or more 
		int i = 0;
		int j = n - 1;
		while(i<j) {
			if (A[i] + A[j] == g) {
				Ans[0] = i;
				Ans[1] = j;
				return Ans;				// Returns {i, j}
				}
			else if(A[i] + A[j] < g)
				i++;
			else
				j--;
		}
	}
	return Ans;							// Returns {-1 -1}
}

//////////////////////////////////////////////////////////////////////
// Problem 2 - O(n^2)

int [] threeElementSum(int n, int [] A, int g)  
{
	int Ans[] = new int[]{-1,-1,-1};
	if(n>=3) {
		int SortedA[] = new int[A.length];
		// Coping A into SortedA
		for (int temp = 0; temp < A.length; temp++) {
			SortedA[temp] = A[temp];
		}
		
		// Sorting Array:SortedA with bubble sort
	    for (int i = 0; i < n-1; i++)
	        for (int j = 0; j < n-i-1; j++)		// Because the end part will start getting sorted with their highest values so no need to check/swap them.
	            if (SortedA[j] > SortedA[j+1]){
	                // swap A[j+1] and A[i] 
	                int temp = SortedA[j]; 
	                SortedA[j] = SortedA[j+1]; 
	                SortedA[j+1] = temp; 
	            }


		int AnsFromTwoValues[] = new int[]{-1, -1};        
	            
	    //Main Algorithm
	    for(int i=0; i<=(n-1)-2;i++) {
	    	int []restOfArray = new int[n - (i+1)];
	    	
	    	for (int temp = 0; temp < restOfArray.length; temp++) {
				restOfArray[temp] = SortedA[temp + (i+1)];
			}
	    	
	    	//Method1 call
	    	AnsFromTwoValues = twoValues(restOfArray, g - SortedA[i]);
	    	
	    	if(AnsFromTwoValues[0] != -1) {
	    		Ans[0] = getArrayIndex(A, SortedA[i]);						// method2 call
	    		Ans[1] = getArrayIndex(A, AnsFromTwoValues[0]);				// method2 call
	    		Ans[2] = getArrayIndex(A, AnsFromTwoValues[1]);				// method2 call
	    		return Ans;
	    	}
	    }
	}
	return Ans;
}

// method1
public int[] twoValues(int[] Array, int g) {
	int j = 0;
	int k = Array.length - 1;
	int Ans[] = new int[]{-1,-1};
	while(j<k) {
		if (Array[j] + Array[k] == g) {
			Ans[0] = Array[j];
			Ans[1] = Array[k];
			return Ans;
			}
		else if(Array[j] + Array[k] < g)
			j++;
		else
			k--;
	}
	return Ans;
}

//method2
public int getArrayIndex(int[] arr,int value) {
    for(int i=0;i<arr.length;i++)
        if(arr[i]==value)
        	return i;
    return -1;
}
//////////////////////////////////////////////////////////////////////
// Problem 3 - O(n)

int numValuesInBoth(int n, int [] A, int [] B)  
{
	int count = 0;
	if(n>=1) {
		for(int i = 0, j = 0; (i <= n-1) && (j <= n-1); ) {
			if(A[i] == B[j]) {
				count++;
				i++;
				j++;
			}
			else if(B[j] < A[i]) {
				while(B[j] < A[i] && (j < n-1) ) {
					j++;
				}
			}
			else if(A[i] < B[j]){
					while(A[i] < B[j] && (i < n-1) ) {
					i++;
					}
			}
			if(j > n-1 || i > n-1) {
				break;
			}
		}
	}
	return count;
}
      
//////////////////////////////////////////////////////////////////////
// Problem 4 - Can't be decided - Reason at the end of Problem 4.

int howManyEntries(int n, int [] A)  
{
	Scanner myObj = new Scanner(System.in);  // NEED TO IMPORT Scanner WHEN USING IN REAL PROGRAM
	for(int i=0; i<10; i++) {
		System.out.print("Enter Value(Except 0): ");
		A[i] = myObj.nextInt();
		for(int j = 0; j < i; j++) {
			if(A[i] == A[j]) {
				A[i] = 0;
				myObj.close();
				return i;
			}
		}
	}
	myObj.close();
	return n;
}
/*	~~~~~~~~~~~~~~~~~~~ QUESTION OF PROBLEM 4 START ~~~~~~~~~~~~~~~~~~~
 * 	(Why can't we determine the running time of this algorithm?)
 * 
 * 	ANSWER] Because this problem asks to get an input from a user, The algorithm is now depending upon the time taken by user to give input which can vary a lot and sometimes if users stops reacting and if does not gives any input - the algorithm does not even gets completed in executing all the statements. So, its not possible to put a mark of time complexity for such kind of algorithms.
	~~~~~~~~~~~~~~~~~~~ QUESTION OF PROBLEM 4 OVER ~~~~~~~~~~~~~~~~~~~~ 
*/

//////////////////////////////////////////////////////////////////////
// Problem 5 - O(lg n)

int indexOf(int n, int [] A, int x)  
{	// If length of A is 0
	if(n == 0) {
		return -1;
	}
	else if(n == 1) {			// If length of A is 1
		if(A[n-1] == x) {
			return n-1;
		}
		else {
			return -1;
		}
	}
	else {						// Otherwise
		int i = 0;
		int j = n-1;
		if(x >= A[i] && x <= A[j]) {
			while( j-i != 1 ) {
				int m = (i+j)/2;
				if(x == A[m]) {
					return m;
				}
				else if(x > m) {
					i = m+1;
					continue;
				}
				else if(x < m) {
					j = m-1;
					continue;
				}
			}
			if(A[i] == x) {
				return i;
			}
			else if(A[j] == x) {
				return j;
			}
		}
	}
	return -1;
}
          
//////////////////////////////////////////////////////////////////////
// Problem 6 - O(n^3)

int [] twoIdenticalRows(int n, int [][] A)
{
	int Ans[] = {-1,-1};
	if(n>=2)
		for(int i = 0; i<= n-2; i++) {
			for(int j = i+1; j<= n-1; j++) {
				for(int k = 0; k <= n-1; k++) {
					if(A[i][k] != A[j][k]) {
						break;
					}
					else if( k==n-1 ){
						Ans[0] = i;
						Ans[1] = j;
						return Ans;
					}
				}
			}
		}
	return Ans;
}

//////////////////////////////////////////////////////////////////////
// Problem 7 - O(n^2)

boolean totallySortedTwoD(int n, int [][] A)  
{
	if(n<1) {						// 2d n x n Array must be at least 1 x 1 2d Array
		return false;
	}
	else
		for(int i = 0; i <= n-1 ; i++) {
			for(int j = 0; j <= n-2; j++ ) {
				if(j == 0 && i != 0) {
					
					if(A[i-1][n-1] >= A[i][j]) {			// Strictly Sorted
						return false;
					}
					
				}
				else {
					
					if(A[i][j] >= A[i][j+1]) {				// Strictly Sorted
						return false;
					}
					
				}
			}
		}
	return true;
}

//////////////////////////////////////////////////////////////////////
// Problem 8 - O(lg n)

int [] coordinatesOf(int n, int [][] A, int x)  
{
	int Ans[] = {-1, -1};
	if(n>=1) {							// 2d n x n Array must be at least 1 x 1 2d Array
		int r=0,m=0;
		if(A[0][0] <= x && A[n-1][n-1] >= x) {
			int top = 0,left = 0;
			int bottom = n-1 ,right = n-1;
			
//			Selecting possible row			
			while(bottom-top != 1) {
				m = (top+bottom)/2;
				if(A[m][0] <= x && x <= A[m][n-1]) {
					r = m;
					break;
				}
				else if(A[m][n-1] < x){
					top = m+1;
					continue;
				}
				else if(x < A[m][0]){
					bottom = m-1;
					continue;
				}
			}
			if(bottom - top == 1) {
				if(A[top][0] <= x && x <= A[top][n-1]) {
					r = top;
				}
				else if(A[bottom][0] <= x && x <= A[bottom][n-1]) {
					r = bottom;
				}
			}
//			Possible row Selected
			
//			Finding in that row
			while( right - left != 1 ) {
				m = (left+right)/2;
				if(x == A[r][m]) {
					Ans[0] = r;
					Ans[1] = m;
					return Ans;
				}
				else if(x > A[r][m]) {
					left = m+1;
					continue;
				}
				else if(x < A[r][m]) {
					right = m-1;
					continue;
				}
			}
			if(A[r][left] == x) {
				Ans[0] = r;
				Ans[1] = left;
				return Ans;
			}
			else if(A[r][right] == x) {
				Ans[0] = r;
				Ans[1] = right;
				return Ans;
			}
		}
		else {
				return Ans;							// Ans = {-1,-1}
		}
	}
	return Ans;										// Ans = {-1,-1}
}
   
//////////////////////////////////////////////////////////////////////
// Problem 9 - O(n+k)

int missing(int n, int [] A, int k)  
{
	if(n>=1) {							// Array to be at least greater than 1
		int ArrayK[] = new int [k];
		for(int i=1; i<=k; i++) {
			ArrayK[i-1] = i;
		}
		for(int j=0; j<=n-1; j++) {
			if(A[j] <= k) {
				ArrayK[ A[j] - 1 ] = 0;
			}
		}
		for(int p=0; p<=k-1; p++) {
			if(ArrayK[p] != 0) {
				return ArrayK[p]; 
			}
		}
	}
	return -1;							// will return -1 when A is empty AND also when all elements in ArrayK will be zero
}
      
//////////////////////////////////////////////////////////////////////
// Problem 10 - O(n.lg n)

int [] twoIdenticalRows(int n, int [][] A)  {
	int Ans[] = {-1, -1};
	int IdenticalRowFromSortedA[] = {-1, -1};
	int SortedA[][] = new int[n][2];
	//		Copying A into SortedA
	for(int i=0; i<=n-1; i++) {
		SortedA[i][0] = A[i][0];
		SortedA[i][1] = A[i][1];
	}
	sort(SortedA,0,n-1,0);
	for(int i=0; i<=n-2; i++) {
		if(SortedA[i][0] == SortedA[i+1][0]) {
			if(SortedA[i][1] == SortedA[i+1][1]) {
				IdenticalRowFromSortedA[0] = SortedA[i][0];
				IdenticalRowFromSortedA[1] = SortedA[i][1];
				break;
			}
		}
	}
	if(IdenticalRowFromSortedA[0] != -1) {
		Ans = getArrayIndex(A, IdenticalRowFromSortedA, Ans);
	}
	return Ans;
}

public void merge(int arr[][], int begin, int mid, int end, int col) {
	int l = mid - begin + 1;
	int r = end - mid;

	int LeftArray[][] = new int [l][2];
	int RightArray[][] = new int [r][2];

	for (int i=0; i<l; i++) {
		LeftArray[i][0] = arr[begin + i][0];
		LeftArray[i][1] = arr[begin + i][1];			
	}

	for (int j=0; j<r; j++) {
		RightArray[j][0] = arr[mid + 1+ j][0];
		RightArray[j][1] = arr[mid + 1+ j][1];			
	}

	int i = 0, j = 0;
	int k = begin;
	while (i<l&&j<r){
		if (LeftArray[i][col] <= RightArray[j][col]){			// Sorting According to column c
			arr[k][0] = LeftArray[i][0];
			arr[k][1] = LeftArray[i][1];
			i++;
		}
		else{
			arr[k][0] = RightArray[j][0];  
			arr[k][1] = RightArray[j][1];  
			j++;  
		}
		k++;  
	}
	while (i<l){
		arr[k][0] = LeftArray[i][0];
		arr[k][1] = LeftArray[i][1];
		i++;  
		k++;  
	}
	while (j<r){
		arr[k][0] = RightArray[j][0];  
		arr[k][1] = RightArray[j][1];
		j++;
		k++;
	}  
}
  
public void sort(int arr[][], int begin, int end, int col) {
	if (begin<end){
		int mid = (begin+end)/2;
		sort(arr, begin, mid, col);
		sort(arr , mid+1, end, col);
		merge(arr, begin, mid, end, col);
	}
}

public int[] getArrayIndex(int arr[][],int IdenticalRowFromSortedA[], int Ans[]) {
	for(int sizeOfAns=0; sizeOfAns<=1;){
		for(int i=0;i<arr.length;i++) {
	        if(arr[i][0]==IdenticalRowFromSortedA[0] && arr[i][1]==IdenticalRowFromSortedA[1]){
	        	Ans[sizeOfAns] = i+1;
	        	sizeOfAns++;				// incremented here
	        	continue;
	        }
		}
	}
    return Ans;
}
