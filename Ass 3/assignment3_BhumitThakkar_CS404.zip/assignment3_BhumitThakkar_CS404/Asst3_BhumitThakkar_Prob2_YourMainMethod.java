// !!!!!!!!!!!!!!!BHUMIT THAKKAR!!!!!!!!!!!!!!!!!!!!!!
//
// Assignment 3, CS-404, Fall 2019


package assignment3;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Asst3_BhumitThakkar_Prob2_YourMainMethod {


	   public static void Floyd(int n, int [][] W, int [][] D, int [][] P) {

		   // for k = 0
		   for (int i = 1; i < n+1 ; i++) {
			   for (int j = 1; j < n+1 ; j++) {
				      D[i][j] = W[i][j];
			   }
		   }
		   
		   for (int k = 1; k < n+1  ; k++) {
			   for (int i = 1; i < n+1 ; i++) {
				   for (int j = 1; j < n+1 ; j++) {
					   if(D[i][j] > D[i][k] + D[k][j]) {
						   D[i][j] = D[i][k] + D[k][j];
						   P[i][j] = k;
					   }
				   }
			   }
		   }
	   
	   } // end Floyd


	   public static void printPath(int s, int d, int [][] P)  {
		   
		   if(P[s][d] != 0){
			   printPath(s,P[s][d],P);
			   System.out.print("V_"+P[s][d]+" ");
			   printPath(P[s][d],d,P);
		   }

	   }  // end printPath
	   

	   public static void printPathWithEndpoints(int s, int d, int [][] P)  {
		   System.out.print("V_"+s+" ");
		   printPath(s,d,P);
		   System.out.print("V_"+d+" ");
	   } // end printPathWithEndpoints
	   
	      
	   

	   public static int maxEdgesInOneOptPath(int n, int [][] P)   {
		   int maxEdge[][] = new int [P.length][P.length];
		   int maxCounter = 0;
		   for (int i = 1; i < P.length; i++) {
			   for (int j = 1; j < P.length; j++) {
				   maxEdge[i][j] = maxEdge(i,j,P);
				   if(maxEdge[i][j] > maxCounter) {
					   maxCounter = maxEdge[i][j];
				   }
			   }
		   }
//		   printArray(n, maxEdge);
		   return maxCounter;
	   }
	   
	   public static int maxEdge(int i, int j,int P[][]) {
		   if(i == j) {
			   return 0;
		   }
		   else if(P[i][j] == 0) {
			   return 1;
		   }
		   else {
			   return maxEdge(i,P[i][j],P) + maxEdge(P[i][j],j,P);
		   }
	   }

		public static void main(String[] args) throws IOException  {

			System.out.println("Bhumit Thakkar");
			System.out.println("CS404: Assignment 3 : Problem 2");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

	      Scanner kbd = new Scanner(System.in);
	      Scanner input;	      
	      String inputFileName;
	      System.out.print("\nEnter input file name:  ");
	      inputFileName = kbd.nextLine();
	      FileReader f = new FileReader(inputFileName);
	      input = new Scanner(f);  

		  int i, j, n = 9;

	      n = input.nextInt();
	      System.out.println();	      
	      int [][] W = new int[n+1][n+1];
	      int [][] D = new int[n+1][n+1];
	      int [][] P = new int[n+1][n+1];

	      for (i = 1; i <= n; i++) 
	         for (j = 1; j <= n; j++)
	            W[i][j] = input.nextInt();	      
	      
	      System.out.println("W is:  ");
	      printArray(n, W);
	      
	      Floyd(n, W, D, P);
	      
	      System.out.println("D is:  ");
	      printArray(n, D);

	      System.out.println("P is:  ");
	      printArray(n, P);
	      
	      System.out.print("\nThe maximum number of edges in a least-cost path is:  ");
	      System.out.println(maxEdgesInOneOptPath(n, P) + "\n");
	      
	      System.out.println("\nShortest paths, intermediates only: \n");
	      for (i = 1; i <= n; i++)  {
	         for (j = 1; j <= n; j++)  {
	            System.out.print("v_" + i + " to v_" + j + ":  ");
	            printPath(i, j, P);
	            System.out.println();
	         }
	         System.out.println();
	      }

	      System.out.println("\n\nShortest paths, all vertices: \n");
	      for (i = 1; i <= n; i++)  {
	         for (j = 1; j <= n; j++)  {
	            printPathWithEndpoints(i, j, P);
	            System.out.println();
	         }
	         System.out.println();
	      }

		}  // end main
	   
	   
	   
	   public static void printArray(int n, int [][] A) {
	      int i, j;
	      System.out.println();
	      System.out.print("       ");
	      
	      for (i = 1; i <= n; i++)
	         System.out.printf("%7d", i);
	      System.out.println("\n");

	      for (i = 1; i <= n; i++) {
	         System.out.printf("%7d", i);
	         for (j = 1; j <= n; j++)
	            System.out.printf("%7d", A[i][j]);
	         System.out.println();
	      }
	      
	      System.out.println();
	   } // end printArray
	               
	            
	}  // end class