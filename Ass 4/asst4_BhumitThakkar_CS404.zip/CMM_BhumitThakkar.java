package assignment4;

import java.io.*;
import java.util.Scanner;

public class CMM_BhumitThakkar {

	   static String name = "Bhumit Thakkar";
	   
	   public static double minMult(int n, double [] d, double [][] M, int [][] P) {
		   // d(n+1) -> 0 - n
		   // M(n+1 x n+1) -> 1 - n
		   // P(n+1 x n+1) -> 1 - n
		   double minCost;
		   double currentCost;
		   for(int diag = 1; diag <= n; diag++){
			   for(int i = 1, j = diag; (i<= n - diag + 1) && (j <= n); i++, j++) {
				   if(i == j) {
					   M[i][j] = 0;
				   }
				   else {
					   minCost = Double.MAX_VALUE;
					   for(int k = i; k <= j-1; k++) {
						   currentCost = M[i][k]+M[k+1][j]+(d[i-1]*d[k]*d[j]);
						   if( minCost >  currentCost ) {
							   minCost = currentCost;
							   P[i][j] = k;
						   }
					   }
					   M[i][j] = minCost;
				   }
			   }
		   }
		   return M[1][n];
	   }  // end minMult method
	      
	   
	   public static double maxMult(int n, double [] d, double [][] M, int [][] P) {
		   // d(n+1) -> 0 - n
		   // M(n+1 x n+1) -> 1 - n
		   // P(n+1 x n+1) -> 1 - n
		   double maxCost;
		   double currentCost;
		   for(int diag = 1; diag <= n; diag++){
			   for(int i = 1; i<= n - diag + 1; i++) {
				   for(int j = diag; j <= n; j++) {
					   if(i == j) {
						   M[i][j] = 0;
					   }
					   else {
						   maxCost = 0;
						   for(int k = i; k <= j-1; k++) {
							   currentCost = M[i][k]+M[k+1][j]+(d[i-1]*d[k]*d[j]);
							   if( maxCost <  currentCost ) {
								   maxCost = currentCost;
								   P[i][j] = k;
							   }
						   }
						   M[i][j] = maxCost;
					   }
				   }
			   }
		   }
		   return M[1][n];
	   }  // end maxMult method

	   

	   public static void printOrder(int i, int j, int [][] P)  {
		   if(i == j) {
			   System.out.print("A_"+i);
		   }
		   else if(j-1 == i) {
			   System.out.print("(A_"+i+"A_"+j+")");
		   }
		   else {
			   System.out.print("(");
			   printOrder(i,P[i][j],P);
			   printOrder(P[i][j]+1,j,P);
			   System.out.print(")");
		   }
	   }  // end printOrder


		public static void main(String[] args) throws IOException  {
	      
	      System.out.println("\n" + name);
	      System.out.println("CS-404, Asst 4, Fall 2019\n\n");

//	      Scanner input = new Scanner(new FileReader("cmm_input.txt"));

	      Scanner input;
	      String inputFilePath = CMM_BhumitThakkar.class.getResource("cmm_input.txt").toString();
	      // If not in main use: this.getClass().getResource("words.txt");
	      inputFilePath = inputFilePath.replace("%20", " ");
	      inputFilePath = inputFilePath.replace("file:/", "");
	      FileReader f = new FileReader(inputFilePath);
	      input = new Scanner(f);  

	      int i, n;
	      double minCost, maxCost;
	      n = input.nextInt();
	      
	      while (n > 0)  {

	         int [][] P  = new int[n+1][n+1];
	         double [] d  = new double[n+1];
	         double [][] M  = new double[n+1][n+1];
	         
	         for (i = 0; i <= n; i++)
	            d[i] = input.nextDouble();
	      
	         minCost = minMult(n, d, M, P);
	         
	         System.out.printf("Minimum Cost to multiply: %1.0f multiplications.", minCost);
	         System.out.println("\n");
	         System.out.print("Optimal Order:  ");
	         printOrder(1, n, P);
	         System.out.println("\n");

	         maxCost = maxMult(n, d, M, P);

	         System.out.printf("Maximum Cost to multiply: %1.0f multiplications.", maxCost);
	         System.out.println("\n");
	         System.out.print("Worst Order:  ");
	         printOrder(1, n, P);
	         System.out.println("\n");
	         
	         System.out.println("ratio:   " + (maxCost / minCost));
	         System.out.println("\n");

	         n = input.nextInt();
		   } // end while loop
	      input.close();
	   } // end main
}
