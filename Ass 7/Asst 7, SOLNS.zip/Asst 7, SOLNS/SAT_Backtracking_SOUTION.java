// CS-404, Satisfiability Backtracking

import java.util.Scanner;
import java.io.*;  


public class SAT_Backtracking_SOUTION
{

// If formula F is NOT satisfiable, then "satisfy" returns false.
// If formula F IS satisfiable, then truthAsst contains a satisfying assignment, with truthAsst[i] = 1 
// if variable x_{i} is true, and 0 if false, and the method returns true.
// This method calls satisfyRec.

   public static boolean satisfy(int n, int k, int [][] F, int [] truthAsst)  {
   
      satisfyRec(0, n, k, F, truthAsst);
      
      return (truthAsst[0] == 1);
   }
   

// This method does the backtracking to search for a satisfying truth assignment.  
// Once (if) it finds a satisfying truth assignment, it does not search for another one (0 points if you do).
   
   public static void satisfyRec(int i, int n, int k, int [][] F, int [] truthAsst)
   {
      if (promising(i, k, F, truthAsst))
      {
         if (i == n)
            truthAsst[0] = 1;

         else
         {
            for (int b = -1; b < 2 && truthAsst[0] == 0; b += 2)
            {
               truthAsst[i+1] = b;
               satisfyRec(i+1, n, k, F, truthAsst);
            }
         }
      }
   }
            

// The promising method for satisfyRec:

   public static boolean promising(int i, int k, int [][] F, int [] truthAsst)
   {
      int badCount;
      for (int j = 1; j <= k; j++)
      {
         badCount = 0;
         
         for (int col = 1; col <= 3; col++)
         {
            int var = Math.abs(F[j][col]);
            if (var > i)
               break;
            else if (truthAsst[var] > 0 && F[j][col] < 0)
               badCount++;
            else if (truthAsst[var] < 0 && F[j][col] > 0)
               badCount++;
         }
         
         if (badCount == 3)
            return false;
      }
      
      return true;
   }


//========================================================================

	public static void main(String[] args) throws IOException  {
    
      FileReader f = new FileReader("formulas.txt");
      Scanner input = new Scanner(f);
      int n, k, i = 0;
      int [][] F;
      int [] truthAsst;
      
      while (input.hasNext())
      {
         i++;
         n = input.nextInt();
         k = input.nextInt();
         F = getNextFormula(k, input);
         truthAsst = new int[n+1];

         satisfy(n, k, F, truthAsst);
                  
         System.out.println("\nFormula " + i + ", n = " + n + ", k = " + k);

         if (truthAsst[0] == 0)
            System.out.println("This formula is NOT satisfiable!");
         else  {
            System.out.println("This forumla IS SATISFIED by this assignment:");      
            printAsst(n, truthAsst);
         }

      }
   }
   

   
   public static void printAsst(int n, int [] truthAsst)
   {
      for (int i = 1; i <= n - 1; i++)
      {
         System.out.print("x_{" + i + "} = ");
         if (truthAsst[i] == 1) 
            System.out.print("T, ");
         else
            System.out.print("F, ");
      }
      
      System.out.print("x_{" + n + "} = ");
      if (truthAsst[n] == 1) 
         System.out.print("T.");
      else
         System.out.print("F.");

         
      System.out.println();
   }

   
   public static int [][] getNextFormula(int k, Scanner input)
   {
      int [][] F = new int[k+1][4];

      for (int i = 1; i <= k; i++) 
         for (int j = 1; j <= 3; j++)
            F[i][j] = input.nextInt();
      
      return F;
   }
   
      


} // end class