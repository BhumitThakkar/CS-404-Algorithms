// CS-404, Fall 2019, Assignment 6.  REPLACE YOURNAME with your name.
// Bhumit Thakkar

public class Asst_6_BhumitThakkar { 

   public static String name = ("BHUMIT THAKKAR");
   
//////////////////////////////////////////////////////////////////////
// Problem 0   (You already did this in Assignment 5--cut and paste the body here.  

      
   public static int greedyColoring(int n, int [][] W, int [] vcolor)  {
	   int color = 0;
	   boolean emptyVertexFound = true;
	   boolean cantColor = false;
	   while(emptyVertexFound) {								// till all vertex colored
		   color++;												// picking new color
		   for (int i = 1; i < vcolor.length; i++) {			// start coloring
			   if(vcolor[i]==0) {								// only color those which are not colored
				   cantColor = false;
				   for (int j = i-1; j >= 1; j--) {				// go back and search all with similar current color
					   if(vcolor[j] == color) {					// for similar color vertex
						   if(W[j][i] == 1) {					// if there is a link
							   cantColor = true;				// don't color then
							   break;
						   }
					   }
				   }
				   
				   if (!cantColor) {							// if no link found
					   vcolor[i] = color;						// color the vertex then
				   }
				   
			   }
		   }
		   // termination condition
		   emptyVertexFound = false;
		   for (int i = 1; i < vcolor.length; i++) {
			   if(vcolor[i] == 0) {
				   emptyVertexFound = true;
			   }
		   }
	   }
	   
      return color;
   }

   
//////////////////////////////////////////////////////////////////////
// Problem 1
   
   public static boolean promising(int i, int [][] W, int [] vcolor)  {
	   boolean promising = true;
	   for(int j = 1; j <= i; j++) {
		   if(W[i][j] == 1 && vcolor[i] == vcolor[j]) {
			   return false;
		   }
	   }
	   return promising;
   }
   
   public static boolean mColorRec(int i, int n, int [][] W, int m, int [] vcolor)  {
	   boolean ans = false;
	   if(promising(i, W, vcolor)) {
		   if(i == n) {
			   return true;
		   }
		   else {
			   for(int t=1; t<=m && ans == false;t++) {
				   vcolor[i+1] = t;
				   ans = mColorRec(i+1, n, W, m, vcolor);
			   }
		   }
	   }
	   return ans;
   }
   
   public static boolean mColor(int n, int [][] W, int m, int [] vcolor)  {
	   boolean ans = false;
	   ans = mColorRec(0,n,W,m,vcolor);
	   return ans;
   }  // end "mColor"
   
   
//////////////////////////////////////////////////////////////////////
// Problem 2

   public static int minNumColorsBacktracking(int n, int [][] W, int [] vcolor)  {
	   for (int m = 1; m <= n; m++) {
		   if(mColor(n, W, m, vcolor)) {
			   return m;
		   }
	   }
	   return -1;
   }  // end "minNumColorsBacktracking"

//////////////////////////////////////////////////////////////////////
// Problem 3

   public static boolean fastTwoColor(int n, int [][] W, int [] vcolor)  {
      boolean ans = true;      							// don't change to false (REASON: for a complete isolated graph)
      
      IntQueue Q = new IntQueue(n);
//      IntQueue QRed = new IntQueue(n);
//      IntQueue QBlue = new IntQueue(n);
      boolean firstNonIsolatexVertexInserted = false;
	  
	  //For Isolated Vertexes:
	  boolean isolatedVertex = true;
	  for (int i = 1; i < W.length; i++) {
		  for (int j = 1; j < W.length; j++) {
			  if(W[i][j] == 1) {
				  isolatedVertex = false;
				  if (firstNonIsolatexVertexInserted == false) {
					  vcolor[i] = 1;
					  Q.enqueue(i);
					  firstNonIsolatexVertexInserted = true;
				  }
				  break;
			  }
		  }
		  if(isolatedVertex == true)
			  vcolor[i] = 1;					// giving any color(here 1)
	  }
	  
	  //For Non Isolated Vertexes:
      while(!Q.isEmpty()) {
    	  int currentV = Q.dequeue();
    	  int otherColor = (vcolor[currentV] == 1)?2:1;
    	  for(int col = 1; col < W.length; col++) {
    		  if(col == currentV) {
					continue;
    		  }
    		  if(W[currentV][col] == 1) {
    			  if(vcolor[col] == vcolor[currentV]) {				// some col & currentV vertex were colored same but have edge between them
    				  return false;
    			  }
    			  else if(vcolor[col] == 0){						// only enQueue visit the non-visited nodes
					vcolor[col] = otherColor;
					Q.enqueue(col);
    			  }
    		  }
    	  }
      }
      return ans;
   } // end "twoColor"


//////////////////////////////////////////////////////////////////////
// Problem 4

   public static boolean getNextSequence(int n, int [] A)  {
       boolean ans = false;
       for (int i = A.length-1; i >= 1; i--) {
    	   if(A[i] == n) {
    		   A[i] = 1;
    		   if(i == 1) {
    			   return false;
    		   }
    	   }
    	   else {
    		   A[i]++;
    		   return true;
    	   }
       }

	   return ans;
   } // end "getNextSequence"


//////////////////////////////////////////////////////////////////////
// Problem 5

   public static boolean validColoring(int n, int [][] W, int [] vcolor)  {
	   
	   // Assuming our Graphs "may be" Directed Graph.
	   for (int i = 1; i < vcolor.length; i++) {
		   for (int j = 1; j < vcolor.length; j++) {
				if(W[i][j] == 1) {
					if(vcolor[i] == vcolor[j]) {
						return false;
					}
				}
		   }
	   }

      return true;
   } // end "validColoring"

   
//////////////////////////////////////////////////////////////////////
// Problem 6

   public static int numDistinctValues(int n, int [] A)  {
	   int count = 0;
	   boolean lastUniqueItem;
	   for (int i = 1; i < A.length; i++) {
		   lastUniqueItem = true;
		   for (int j = i; j < A.length; j++) {
				if(i != j && A[i] == A[j]) {
					lastUniqueItem = false;
					break;
				}
		   }
		   if (lastUniqueItem) {
			   count++;
		   }
	   }
	   return count;
   }// end "numDistinctValues"
   
         

//////////////////////////////////////////////////////////////////////
// Problem 7
         
   public static int minNumColorsBruteForce(int n, int [][] W)  {
	   int minColors = n+1;
	   int currentColoring = 0;
	   
	   int A[] = new int[n+1];
	   for (int i = 1; i < A.length; i++) {
		   if(i != A.length - 1) {
			   A[i] = 1;
		   }
	   }
	   while(getNextSequence(n, A)) {
		   if(validColoring(n, W, A)) {
			   currentColoring = numDistinctValues(n, A);
			   if(currentColoring < minColors) {
				   minColors = currentColoring; 
			   }
		   }
	   }

	   return minColors;
   }  // end "minNumColorsBruteForce"
   
   

//////////////////////////////////////////////////////////////////////
// printArray

   public static void printArray(int n, int [] A) {
      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
      System.out.println();
   }

//////////////////////////////////////////////////////////////////////
// main

   public static void main(String [] args)  {

      System.out.println("\n" + name);
      System.out.println("CS-404, Fall 2019, Assignment 6\n");
      
      int i, n, m;
      int [] vcolor;
      int [][] W;
      boolean done, found;


      System.out.println("\n======== Testing Problems 1, 2, and 3 ============================================\n");
      
      for (i = 1; i <= graphs.length - 1; i++)  {
      
         W = graphs[i];
         n = W.length - 1;

         vcolor = new int[n+1];
         System.out.println("\nGraph " + i + ", size = " + n + "\n");
         m = greedyColoring(n, W, vcolor);
         System.out.println(m + " colors are used by the Greedy Algorithm for Graph " + i + ":");
         printArray(n, vcolor);
        
         vcolor = new int[n+1];
         m = minNumColorsBacktracking(n, W, vcolor);
         System.out.println("\n" + m + " colors are necessary for Graph " + i + ":");
         printArray(n, vcolor);

         vcolor = new int[n+1];
         System.out.println("\nRunning fast two-coloring algorithm...");
         if (fastTwoColor(n, W, vcolor))  {
         
            System.out.println("2-coloring FOUND:");
            printArray(n, vcolor);
         }
         else  
            System.out.println("No 2-coloring found!");
    
         
         System.out.println();
         
      }
      
      
      System.out.println("\n======== Testing Problem 4 ============================================\n");
      
      int [] A1 = {-1, 3, 1, 4, 4};
      n = A1.length - 1;
      System.out.print("A is:  ");
      printArray(n, A1);
      done = getNextSequence(n, A1);
      System.out.println("Found next sequence is " + done);
      System.out.print("A is:  ");
      printArray(n, A1);
      
      int [] A2 = {-1, 5, 5, 5, 5, 5};
      n = A2.length - 1;
      System.out.print("\nA is:  ");
      printArray(n, A2);
      done = getNextSequence(n, A2);
      System.out.println("Found next sequence is " + done);
      System.out.print("A is:  ");
      printArray(n, A2);

      int [] A3 = {-1, 4, 7, 6, 7, 7, 7, 7};
      n = A3.length - 1;
      System.out.print("\nA is:  ");
      printArray(n, A3);
      done = getNextSequence(n, A3);
      System.out.println("Found next sequence is " + done);
      System.out.print("A is:  ");
      printArray(n, A3);
      
     
      System.out.println("\n======== Testing Problem 5 ============================================\n");
         
      int vcoloring [][] = 
      {
      {},
      {-1, 1, 2},
      {-1, 2, 1, 2},
      {-1, 1, 2, 3, 1},
      {-1, 1, 1, 2, 3, 3, 3, 4, 4},
      {-1, 1, 2, 1, 2, 3, 3, 3, 4, 1},
      {-1, 1, 1, 2, 1, 3, 5, 2, 2, 2, 3, 4, 5}, 
      {-1, 1, 1, 2, 1, 3, 5, 2, 2, 2, 3, 4, 5}, 
      {-1, 1, 1, 1, 1, 2, 2, 1, 2, 3, 3, 1, 2, 1, 3, 2, 2, 1, 3, 3, 2, 1, 2, 2, 4, 2}
      };
      
      for (i = 1; i <= graphs.length - 1; i++) {
      
         
         System.out.print("The coloring is valid for graph " + i + ":  ");
         System.out.println(validColoring(graphs[i].length - 1, graphs[i], vcoloring[i]));
      }


      System.out.println("\n======== Testing Problem 6 ============================================\n");
      
      int [] AA = {-1, 5, 3, 19, 3, 3, 5, 19, 4, 4, 27, 3, 3};
      n = AA.length - 1;
      System.out.println("Number of distinct values in AA is:  " + numDistinctValues(n, AA));
      
      int [] BB = {-1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8};
      n = BB.length - 1;
      System.out.println("Number of distinct values in BB is:  " + numDistinctValues(n, BB));
      
      int [] CC = {-1, 9, 4, 1, 7, 3, 6, 2, 8, 5};
      n = CC.length - 1;
      System.out.println("Number of distinct values in CC is:  " + numDistinctValues(n, CC));



      System.out.println("\n======== Testing Problem 7 ============================================\n");


      for (i = 1; i <= 5; i++)  {
      
         W = graphs[i];
         n = W.length - 1;
                 
         m = minNumColorsBruteForce(n, W);
         System.out.println("\n" + m + " colors are necessary for Graph " + i + ":");
      }
               
   }






//////////////////////////////////////////////////////////////////////
// data

public static int [][][] graphs = 

{
{}, 

// 1
{
{},
{-1, 0, 1},
{-1, 1, 0}
},

// 2
{
{},
{-1, 0, 1, 1},
{-1, 1, 0, 1},
{-1, 1, 1, 0}
},

// 3
{
{},
{-1, 0, 1, 0, 1},
{-1, 1, 0, 0, 1},
{-1, 0, 0, 0, 1},
{-1, 1, 1, 1, 0}
},


// 4
{
{},
{-1,0,0,0,1,0,1,0,1},
{-1,0,0,1,0,1,0,1,0},
{-1,0,1,0,0,0,1,0,1},
{-1,1,0,0,0,1,0,1,0},
{-1,0,1,0,1,0,0,0,1},
{-1,1,0,1,0,0,0,1,0},
{-1,0,1,0,1,0,1,0,0},
{-1,1,0,1,0,1,0,0,0}
},

// 5
{
{},
{-1,0,1,0,1,1,0,1,1,0},
{-1,1,0,0,0,1,1,0,0,1},
{-1,0,0,0,0,0,0,1,1,0},
{-1,1,0,0,0,0,0,1,1,1},
{-1,1,1,0,0,0,0,0,1,1},
{-1,0,1,0,0,0,0,0,0,1},
{-1,1,0,1,1,0,0,0,1,0},
{-1,1,0,1,1,1,0,1,0,1},
{-1,0,1,0,1,1,1,0,1,0}
},

// 6
{
{},
{-1,0,0,0,0,0,0,0,1,0,1,0,1},
{-1,0,0,1,0,0,0,1,1,0,1,0,0},
{-1,0,1,0,0,1,0,0,0,0,0,0,0},
{-1,0,0,0,0,1,0,0,0,1,0,1,0},
{-1,0,0,1,1,0,0,0,0,0,0,0,1},
{-1,0,0,0,0,0,0,1,1,0,0,0,0},
{-1,0,1,0,0,0,1,0,0,0,0,0,0},
{-1,1,1,0,0,0,1,0,0,0,0,1,0},
{-1,0,0,0,1,0,0,0,0,0,1,0,1},
{-1,1,1,0,0,0,0,0,0,1,0,1,0},
{-1,0,0,0,1,0,0,0,1,0,1,0,1},
{-1,1,0,0,0,1,0,0,0,1,0,1,0}
},


// 7
{
{},
{-1,0,0,0,1,0,0,0,0,0},
{-1,0,0,1,0,0,1,0,0,0},
{-1,0,1,0,0,1,0,0,1,0},
{-1,1,0,0,0,0,1,1,0,1},
{-1,0,0,1,0,0,1,1,1,0},
{-1,0,1,0,1,1,0,1,1,1},
{-1,0,0,0,1,1,1,0,1,0},
{-1,0,0,1,0,1,1,1,0,1},
{-1,0,0,0,1,0,1,0,1,0}
},

// 8
{
{},
{-1,0,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0},
{-1,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,1,0,1,0,0,0,0,1},
{-1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,1,0,0,0},
{-1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,1,0,0,0,1,0,0,1,0,0},
{-1,0,1,0,0,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0},
{-1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0},
{-1,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1},
{-1,0,0,0,1,0,0,0,0,0,1,1,0,1,0,0,0,0,0,0,0,1,0,0,0,0},
{-1,0,0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,1,0},
{-1,1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,1,0,1,0,0,0},
{-1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,0,0},
{-1,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0},
{-1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1},
{-1,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,1},
{-1,0,0,1,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0},
{-1,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0},
{-1,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,0,1,0,0},
{-1,0,1,1,0,0,1,0,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,0,0},
{-1,0,0,0,0,0,1,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1,0},
{-1,0,1,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1,0,0,0,1,0,0,0,0},
{-1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
{-1,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0},
{-1,0,0,0,1,0,0,0,0,0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0},
{-1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1,0,0,1},
{-1,0,1,0,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,1,0,0,1,0}
}

};



   
} // end class
   
      
   


      

