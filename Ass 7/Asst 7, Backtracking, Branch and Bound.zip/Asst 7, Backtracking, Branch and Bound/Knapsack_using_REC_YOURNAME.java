// CS-404, Knapsack Using Recursion.

public class Knapsack_using_REC_YOURNAME  {

// Use this global variable to keep track of how many nodes are visited:
   public static int numNodesVisited = 0;
  
   
// After the following method is called, best[0] gives the opimtal profit for the instance of the 
// 0-1 knapsack problem given n, p, w, and W. For the other cells, best[i] = 1.0 if
// item i should be taken, and best[i] = 0.0 if item i should not be taken.
// Also, after this method is called, the global variable "numNodesVisited" will contain
// the number of nodes visited to solve this instance. 
// This method will call "knapsack_rec" below.
   
   public static void knapsack(int n, double [] p, double [] w, double W, double [] best)  {
   



   }
      
      
// This method is called by "knapsack" above.  It updates best[0] (maxProfit) and then if 
// where it is is promising will make recursive calls for each child.

   public static void knapsack_rec(int i,
                                   double currentProfit,
                                   double currentWeight,
                                   int n,
                                   double [] p,
                                   double [] w,
                                   double W,
                                   int [] include,
                                   double [] best) {





   } // end knapsack_rec
   
   
   
 // The promising method for "knapsack_rec":

   public static boolean promising(int i,
                                   double currentProfit,
                                   double currentWeight,
                                   int n,
                                   double [] p,
                                   double [] w,
                                   double W,
                                   int [] include,
                                   double [] best) {
                                   

      return false; // just to make it compile                               
   } // end promising



//=======================================================================
     
   public static void main(String [] args)  {
      
      int n;
      double w [], p [], W;
   
      for (int j = 1; j <= NUM_TESTS; j++)  {
      
         p = p_Array[j];
         w = w_Array[j];
         n = p.length - 1;
         W = capacity_Array[j];
      
         double [] best = new double[n+1];
         knapsack(n, p, w, W, best);
         
         System.out.println("\nTest " + j + ":  ");
         System.out.println("0-1 optimal profit:  $" + best[0]);
         System.out.println("Number of nodes visited:  " + numNodesVisited);
         printSubset(n, best);
      }
   }
   
  
   public static void printSubset(int n, double [] A)  {
   
      System.out.print("Take these items:  ");
      for (int i = 1; i <= n; i++)
         if (A[i] == 1)
            System.out.print(i + " ");
      System.out.println();
   }
      
   
   public static double [] capacity_Array = {0, 11, 16, 13, 25, 405, 13};   
   
   public static double [][] p_Array = 
      {
         {},
         {0, 20, 30, 35, 12, 3},
         {0, 40, 30, 50, 10},
         {0, 20, 30, 35, 12, 3},         
         {0, 18, 30, 40, 21, 24},
         {0, 320, 350, 900, 700, 650, 420, 504, 600, 150, 120},
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 13},
      };
      
   public static double [][] w_Array = 
      {
         {},
         {0, 2, 5, 7, 3, 1},
         {0, 2, 5, 10, 5},
         {0, 2, 5, 7, 3, 1},
         {0, 3, 6, 10, 7, 12},
         {0, 85, 95, 250, 200, 195, 140, 170, 230, 60, 50},
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 13},        
      };
         
   public static int NUM_TESTS = p_Array.length - 1; 

   
} // end class